IronClad Ad Blocker - Chrome extension 1.4.0 (works with IronCladOS)
====================================================================

CHANGES IN 1.4.0
- New "glass" look (frosted, translucent panels with a bright rim, pill buttons, iOS-style switches) in the popup,
  the "blocked" page and the in-page cards. The popup has a faint pink binary rain behind the glass.
- Zapper: hide any annoying element (newsletter pop-ups, floating banners, cookie walls).
    Start it from the popup ("Pick an element"), the right-click menu ("IronClad: Pick an element to zap...") or
    Alt+Shift+Z (change it at chrome://extensions/shortcuts). "IronClad: Zap this element" in the right-click menu
    hides the exact element you right-clicked.
    While picking: move = highlight, click or Enter = hide, Up arrow = bigger (parent), Down = smaller, Esc = finish.
    The element is hidden at once. "Save rule" keeps it for that site (stored only in this browser, applied on every
    visit before the page paints); "Undo" brings it back. Tick "Save every zapped element for this site" in the popup
    to skip the button. Saved rules are listed (and removable) in the popup.
    If the thing you hide was freezing the page's scrolling (cookie walls usually do), the rule also gives scrolling back.
    Selectors are built from ids and stable attributes/classes; vague class names (box, content, wrapper...) are
    anchored to a parent so a rule cannot hide unrelated things on the site's other pages.
    While the app manages the extension, the app can turn the Zapper off (Settings -> Chrome extension).
- Live badge counter: the number on the toolbar icon counts up as ads/trackers are blocked on the tab you are
  looking at, flashes bright and fades back to teal, and a thin ring pulses around the icon. Big jumps count up in a
  few quick steps. It counts blocked requests + stopped pop-ups/redirects + YouTube ads, and starts again from zero
  on every new page. The popup shows the same number live, with a breakdown (requests, pop-ups, YouTube, ad slots
  hidden, zapped elements).
    Needs the unpacked install (Load unpacked), because Chrome only reports individual rule matches to unpacked
    extensions. In a packed install Chrome keeps counting requests itself: the badge still pulses when it changes,
    but pop-ups / YouTube ads are not added to it (the popup still lists them).
- New permissions: "contextMenus" (right-click items) and "scripting" (starts the Zapper on the page you pick).

CHANGES IN 1.3.7
- The "Ad blocked by IronClad" message (and its timer bar) use the blue-green of the IronClad logo, #0fb8a4.
  To use another colour, edit FLASH_COLOR in content.js.

CHANGES IN 1.3.5
- The black screen over the YouTube player now reads "Ad blocked by IronClad" in larger type and stays for 2 seconds
  (was 3). To change the time, edit FLASH_MS in content.js (milliseconds).

CHANGES IN 1.3.4
- New: when a YouTube ad is skipped, a black "Ad skipped by IronClad" screen covers the player for 3 seconds so you
  can see it happen. It appears when the extension removes the ad schedule from a video (the usual case, so no ad
  ever plays) and when the player enters ad mode and the fallback skipper fast-forwards it. The video keeps
  playing underneath, and YouTube's control bar stays usable. Switch it off in the popup, or in the app's
  settings while paired.

CHANGES IN 1.3.3 (reliability release; use it together with the matching ironclad_improved.py)
- Advertiser dashboards on tracker-style hostnames (analytics.google.com, ads.twitter.com, ads.linkedin.com,
  ads.reddit.com, ads.pinterest.com, ads.tiktok.com, Yahoo advertising ...) open normally instead of showing the
  "blocked" window, and the page's own requests work. Other sites' requests to those hosts are still blocked.
- Blocklist parsing no longer widens narrow rules: a rule limited to one site or one resource type ($domain=,
  $image, ~third-party ...) is skipped instead of blocking the whole domain, and @@ exception rules are honoured
  (they never override the malware feeds).
- If Chrome rejects part of a list, only the rejected domains are dropped (the old code threw away half the list).
  The popup now says how many were rejected, also when the app manages the lists (the old warning was hidden then).
- A problem applying the app's rules is no longer reported as "IronCladOS isn't running".
- Built-in list: added bounceexchange.com, crwdcntrl.com, ay.delivery, primis.tech, vidazoo.com and
  region1.analytics.google.com (the GA4 collection endpoint).
- Rule ids are now fixed per kind: exceptions 10-49, security 100-4999, ads 5000+.

CHANGES IN 1.3.2
- YouTube: yt.js removes the ad schedule (adPlacements / playerAds / adSlots) from the player
  data before the player reads it, so ads are not requested and there is no black screen to wait out.
- The skipper (fallback) is faster: checks every 100 ms and on every video event, seeks the ad to
  its end as soon as it is seekable, and now restores sound and playback speed afterwards.
  (1.3.0 muted the video during ads and never unmuted it.)

CHANGES IN 1.3.0
- Popup / redirect protection now actually runs. In 1.2.x it lived in content.js, which Chrome
  runs in an isolated world, so page scripts never hit it. The hooks now live in inject.js
  (manifest "world": "MAIN") and use window.open + the Navigation API.
- When a popup or scripted redirect is stopped, a "Popup blocked / Redirect blocked" card appears
  in the page asking whether to continue ("Keep blocked" / "Continue anyway"). It follows the app's
  "show blocked window" and "allow continue" policy.
- Blocked popups are reported to the IronCladOS app (shown as "Chrome · popup").
- Policy changes made in the app are picked up on every page load (before: every 30 s).
- Works with the updated ti3.py: Chrome keeps blocking even when "Start protection" is off,
  unless you tick "Chrome blocking follows Start protection" in the app.

INSTALL / UPDATE
1. Unzip over the old folder (or somewhere permanent).
2. chrome://extensions -> Developer mode ON -> "Load unpacked" (first time)
   or click the reload arrow on the IronClad card (update). Reload open tabs afterwards.

CONNECT TO THE APP (so the app controls Chrome)
1. Start IronCladOS. Settings should show the bridge listening on 127.0.0.1:8898.
2. Click the extension icon -> "Connect to app".
3. Approve the request in the IronCladOS window.
From then on the popup shows "Managed by IronCladOS" and its switches are locked.

WHAT STOPS ADS / REDIRECTS / POP-UPS
1. declarativeNetRequest (domain blocklists) - requests to listed domains are dropped; a
   top-level navigation to a listed domain opens the IronClad "blocked" page.
2. Cosmetic rules in content.js hide common ad slots.
3. inject.js - blocks window.open() that nobody asked for (no click behind it) and scripted
   redirects of the tab to another site. Popups that follow a real click are allowed (login
   windows etc.); if they point at a listed domain, rule 1 still catches them.
4. Chrome's own popup blocker (chrome://settings/content/popups) - keep it strict.

WHAT IT CANNOT FULLY STOP
- Ads served from the same domain as the page (e.g. YouTube video ads): only the skipper and
  cosmetic rules apply.
- Ad domains that are not on any list.
- Click-hijack popups (a popup opened by a real click on the page) to unlisted domains.
- A site's own legitimate scripted redirect with no click behind it (e.g. some single sign-on
  pages) will also trigger the card - choose "Continue anyway".

STANDALONE MODE (not connected)
Works on its own with the StevenBlack / Peter Lowe / URLhaus lists,
refreshed every 6 hours.

LIMITS
- Network blocking is by domain only. (The IronCladOS proxy sees only the host name of HTTPS traffic; it does not
  decrypt it, so it cannot block by URL path.)
- A page opened on one of the dashboard hosts above is treated like a paused site: ads it loads itself are not blocked.
- YouTube changes its player often; the skipper may need updates.
- The app link only accepts requests from a browser extension you approved, on 127.0.0.1.
