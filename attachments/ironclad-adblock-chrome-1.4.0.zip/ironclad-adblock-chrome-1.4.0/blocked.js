const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const reason = params.get("r") || "ads";
// security | ads | popup
const KIND = reason === "security" ? "security" : (reason === "popup" ? "popup" : "ads");

let url = null;
try {
  const u = new URL(location.hash.slice(1));
  if (u.protocol === "http:" || u.protocol === "https:") url = u;
} catch (e) {}

document.body.dataset.kind = KIND === "security" ? "security" : "ads";

const TITLES = {
  security: "Dangerous site blocked",
  ads: "Ad blocked",
  popup: "This is an ad / popup"
};
const LEADS = {
  security: "This address is on a malware / phishing feed. Opening it could put your device or accounts at risk.",
  ads: "This page tried to open a domain that is on your ad and tracker lists, so IronClad stopped it.",
  popup: "A website tried to open a new tab or force a redirect to this address. IronClad blocked it because it looks like an ad or unwanted popup."
};

$("title").textContent = TITLES[KIND] || TITLES.ads;
$("lead").textContent = LEADS[KIND] || LEADS.ads;
$("host").textContent = url ? url.hostname : (KIND === "popup" ? "Blocked popup / redirect" : "Unknown address");
$("full").textContent = url ? url.href : "";
if (KIND === "security" || !url) $("always").hidden = true;
if (!url) $("go").disabled = true;

// While the app manages the extension, "Always allow" is app-only and "Continue anyway" follows the app's setting.
chrome.runtime.sendMessage({ type: "state" }, (st) => {
  if (!st) return;
  if (st.managed) {
    $("always").hidden = true;
    if (!st.canContinue) {
      $("go").hidden = true;
      $("foot").textContent = "IronCladOS is set to keep this blocked. To open it, allow the site in the IronCladOS app.";
    }
  }
});

$("back").onclick = async () => {
  if (history.length > 1) { history.back(); return; }
  const tab = await chrome.tabs.getCurrent();   // pop-up / new-tab ad: just close it
  if (tab) chrome.tabs.remove(tab.id); else window.close();
};

let armed = false;
$("go").onclick = async () => {
  if (!url) return;
  if (KIND === "security" && !armed) {          // extra confirmation for malware/phishing
    armed = true;
    $("go").textContent = "Yes, continue anyway (not recommended)";
    $("go").classList.add("danger");
    return;
  }
  await chrome.runtime.sendMessage({ type: "bypass", url: url.href });
  location.replace(url.href);
};

$("always").onclick = async () => {
  if (!url) return;
  await chrome.runtime.sendMessage({ type: "allow", host: url.hostname });
  location.replace(url.href);
};
