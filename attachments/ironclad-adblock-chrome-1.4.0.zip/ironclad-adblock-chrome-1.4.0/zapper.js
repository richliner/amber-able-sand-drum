// zapper.js - the Zapper: point at an annoying element, click, and it disappears.
//
// Injected on demand by background.js (popup button, right-click menu or Alt+Shift+Z); it is not loaded on
// pages where you never use it. Clicking an element hides it at once by injecting a CSS rule, and you can save
// that rule for the site (stored only in this browser, applied by content.js on every visit).
//
// While picking:   move the mouse = highlight    click / Enter = hide it     Up = bigger (parent)
//                  Down = smaller (child)         Esc = finish
(() => {
  if (window.__icZapper) return;
  const Z = (window.__icZapper = { active: false });

  const hostName = location.hostname.toLowerCase().replace(/^www\./, "");
  const send = (msg) => { try { return chrome.runtime.sendMessage(msg); } catch (e) { return Promise.resolve(undefined); } };

  // ---------------------------------------------------------------------------------------------------------
  // 1. Building a CSS selector that finds exactly the element you clicked - and survives a reload
  // ---------------------------------------------------------------------------------------------------------
  const esc = (s) => (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_\u00A0-\uFFFF-]/g, "\\$&");
  const attrVal = (v) => String(v).replace(/["\\]/g, "\\$&");
  // classes that describe a temporary state, and generated ones (css-1x2y3z, sc-AbCdEf, a1b2c3d4 ...), are no use in a rule
  const STATE = /^(active|open|opened|show|shown|visible|hidden|in|out|fade|fading|collapse|collapsed|collapsing|focus|focused|hover|selected|loaded|loading|disabled|current|enter|leave|is-[\w-]+|has-[\w-]+|js-[\w-]+)$/i;
  const generated = (s) => /^(css|sc|jsx|svelte|emotion|styled|chakra|mui|makeStyles)-/i.test(s) || /\d{3,}/.test(s) ||
    (/\d/.test(s) && /[a-z]/i.test(s) && s.length >= 7 && !/^[a-z]+(-[a-z0-9]+)*$/i.test(s));
  const goodClasses = (el) => [...el.classList].filter((c) => c.length <= 40 && !STATE.test(c) && !generated(c));
  const ATTRS = ["data-testid", "data-test", "data-test-id", "data-qa", "data-cy", "data-component", "data-name", "role", "aria-label", "aria-modal"];

  const unique = (sel, el) => { try { const l = document.querySelectorAll(sel); return l.length === 1 && l[0] === el; } catch (e) { return false; } };
  const idOk = (el) => !!el.id && !generated(el.id) && unique("#" + esc(el.id), el);

  // Class names that say nothing about WHAT an element is. A rule such as "div.box" would also hide unrelated things on
  // the site's other pages, so these are only accepted together with a parent in the selector.
  const GENERIC = /^(box|container|wrapper|wrap|content|main|inner|outer|item|items|row|col|column|text|title|body|header|footer|btn|button|link|list|image|img|section|block|layout|page|app|root|inside|group|cell|grid|flex|small|large|big)$/i;

  // the shortest thing that already identifies the element on its own ("" if it needs a path)
  function standalone(el) {
    const tag = el.tagName.toLowerCase();
    if (idOk(el)) return "#" + esc(el.id);
    for (const a of ATTRS) {
      const v = el.getAttribute(a);
      if (v && v.length <= 60 && !/[\n\r]/.test(v)) { const s = `${tag}[${a}="${attrVal(v)}"]`; if (unique(s, el)) return s; }
    }
    const cls = goodClasses(el);
    if (cls.length && cls.every((c) => GENERIC.test(c))) return "";          // too vague on its own: use the path
    for (let n = 1; n <= Math.min(3, cls.length); n++) { const s = tag + cls.slice(0, n).map((c) => "." + esc(c)).join(""); if (unique(s, el)) return s; }
    return "";
  }
  // one step of a path (not necessarily unique by itself)
  function segment(el) {
    if (idOk(el)) return "#" + esc(el.id);
    let seg = el.tagName.toLowerCase();
    const cls = goodClasses(el).slice(0, 2);
    if (cls.length) seg += cls.map((c) => "." + esc(c)).join("");
    const p = el.parentElement;
    if (p) {
      const same = [...p.children].filter((c) => c.tagName === el.tagName);
      let alike = 0;
      try { alike = [...p.children].filter((c) => c.matches(seg)).length; } catch (e) { alike = 2; }
      if (alike > 1) seg += `:nth-of-type(${same.indexOf(el) + 1})`;
    }
    return seg;
  }
  function buildSelector(el) {
    if (!el || el.nodeType !== 1) return "";
    const own = standalone(el);
    if (own) return own;
    const parts = [];
    const vague = goodClasses(el).every((c) => GENERIC.test(c)) && !idOk(el);       // bare tag or only generic classes
    for (let cur = el; cur && cur.nodeType === 1 && cur !== document.documentElement; cur = cur.parentElement) {
      const seg = segment(cur);
      parts.unshift(seg);
      const sel = parts.join(" > ");
      if ((parts.length > 1 || !vague) && unique(sel, el)) return sel.length <= 400 ? sel : "";
      if (seg.startsWith("#")) break;
    }
    // last resort: the exact position in the page
    const path = [];
    for (let cur = el; cur && cur.nodeType === 1 && cur !== document.documentElement; cur = cur.parentElement) {
      const p = cur.parentElement;
      path.unshift(p ? `${cur.tagName.toLowerCase()}:nth-child(${[...p.children].indexOf(cur) + 1})` : cur.tagName.toLowerCase());
    }
    const sel = "html > " + path.join(" > ");
    return unique(sel, el) && sel.length <= 400 ? sel : "";
  }
  const describe = (el) => {
    const s = el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + goodClasses(el).slice(0, 2).map((c) => "." + c).join("");
    return s.length > 46 ? s.slice(0, 45) + "…" : s;
  };

  // A cookie wall or modal usually freezes the page behind it (overflow: hidden). If the thing you hide looks like
  // that overlay, the rule also gives the page its scrolling back.
  function lockedScroll(el) {
    try {
      const cs = getComputedStyle(el), r = el.getBoundingClientRect();
      const overlay = cs.position === "fixed" || cs.position === "sticky" || r.width * r.height > innerWidth * innerHeight * 0.25;
      const locked = [document.documentElement, document.body].some((n) => n && /hidden|clip/.test(getComputedStyle(n).overflowY));
      return overlay && locked;
    } catch (e) { return false; }
  }
  const UNLOCK_CSS = "html,body{overflow:auto!important}";

  // ---------------------------------------------------------------------------------------------------------
  // 2. What has been hidden in this visit (undo-able) and the CSS that hides it
  // ---------------------------------------------------------------------------------------------------------
  const session = [];            // { sel, unlock, label, savedId, savedHost }
  let sessionStyle = null, autoSave = false;
  function renderSession() {
    if (!sessionStyle || !sessionStyle.isConnected) {
      sessionStyle = document.createElement("style");
      sessionStyle.setAttribute("data-ironclad", "zap-session");
      (document.head || document.documentElement).appendChild(sessionStyle);
    }
    sessionStyle.textContent = session.map((e) => `${e.sel}{display:none!important}`).join("\n") +
      (session.some((e) => e.unlock) ? "\n" + UNLOCK_CSS : "");
  }

  // ---------------------------------------------------------------------------------------------------------
  // 3. The overlay (a glass panel in a shadow root, so the page's CSS can't touch it)
  // ---------------------------------------------------------------------------------------------------------
  const CSS_TEXT = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;
      font: 13px/1.4 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; color: #f5f9fc; }
    .glass { pointer-events: auto; position: absolute; isolation: isolate;
      background: linear-gradient(150deg, rgba(255,255,255,.20), rgba(255,255,255,.07)), rgba(14, 22, 38, .46);
      -webkit-backdrop-filter: blur(24px) saturate(185%); backdrop-filter: blur(24px) saturate(185%);
      border: 1px solid rgba(255,255,255,.18); border-radius: 999px; padding: 9px 10px 9px 16px;
      box-shadow: inset 0 1px 0 rgba(255,255,255,.42), 0 14px 36px rgba(2,6,18,.45);
      display: flex; align-items: center; gap: 10px; white-space: nowrap; max-width: calc(100vw - 24px); }
    .glass::before { content: ""; position: absolute; inset: 0; border-radius: inherit; z-index: -1; pointer-events: none;
      background: linear-gradient(180deg, rgba(255,255,255,.22), rgba(255,255,255,0) 45%); }
    .bar { top: 14px; left: 50%; transform: translateX(-50%); }
    .toast { bottom: 22px; left: 50%; transform: translateX(-50%); animation: rise .25s cubic-bezier(.2,1.1,.3,1); }
    @keyframes rise { from { opacity: 0; transform: translate(-50%, 14px) scale(.96); } }
    .dot { width: 9px; height: 9px; border-radius: 50%; background: #ff5fb0; box-shadow: 0 0 10px #ff5fb0; flex: none; }
    .dim { color: rgba(236,246,251,.62); font-size: 12px; overflow: hidden; text-overflow: ellipsis; }
    b { font-weight: 600; max-width: 260px; overflow: hidden; text-overflow: ellipsis; display: inline-block; vertical-align: bottom; }
    button { font: 600 12px/1 inherit; font-family: inherit; border: 0; border-radius: 999px; padding: 8px 13px; cursor: pointer; color: #f5f9fc;
      background: rgba(255,255,255,.14); box-shadow: inset 0 1px 0 rgba(255,255,255,.30), inset 0 0 0 1px rgba(255,255,255,.10); }
    button:hover { background: rgba(255,255,255,.22); }
    button.go { color: #03221e; background: linear-gradient(180deg, #4ff0dc, #0fb8a4); box-shadow: inset 0 1px 0 rgba(255,255,255,.55), 0 4px 14px rgba(15,184,164,.35); }
    .box { position: absolute; border: 2px solid #ff5fb0; border-radius: 6px; background: rgba(255,95,176,.15);
      box-shadow: 0 0 0 1px rgba(255,255,255,.35), 0 0 18px rgba(255,95,176,.55); transition: left .06s, top .06s, width .06s, height .06s; }
    .tag { position: absolute; font: 600 11px/1 ui-monospace, "SF Mono", Menlo, Consolas, monospace; color: #fff; padding: 5px 8px; border-radius: 8px;
      background: rgba(255,95,176,.92); box-shadow: 0 4px 12px rgba(0,0,0,.3); max-width: 70vw; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .poof { position: absolute; border: 2px solid #5eead6; border-radius: 10px; animation: poof .42s ease-out forwards; }
    @keyframes poof { to { opacity: 0; transform: scale(1.12); box-shadow: 0 0 30px #5eead6; } }
    @media (prefers-reduced-motion: reduce) { .toast, .poof { animation: none; } .box { transition: none; } }
  `;
  const h = (tag, cls, ...kids) => { const e = document.createElement(tag); if (cls) e.className = cls; for (const k of kids) e.append(k); return e; };
  let hostEl = null, root = null, boxEl = null, tagEl = null, barEl = null, toastEl = null, toastTimer = 0;

  function ensureUI() {
    if (hostEl && hostEl.isConnected) return;
    hostEl = document.createElement("div");
    hostEl.setAttribute("data-ironclad", "zapper");
    hostEl.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    const sh = hostEl.attachShadow({ mode: "closed" });
    const st = document.createElement("style"); st.textContent = CSS_TEXT;
    root = h("div", "root");
    boxEl = h("div", "box"); boxEl.hidden = true;
    tagEl = h("div", "tag"); tagEl.hidden = true;
    root.append(boxEl, tagEl);
    sh.append(st, root);
    (document.documentElement || document).appendChild(hostEl);
  }
  function dropUI() { clearTimeout(toastTimer); if (hostEl) { try { hostEl.remove(); } catch (e) {} } hostEl = root = boxEl = tagEl = barEl = toastEl = null; }

  function showBar() {
    ensureUI();
    if (barEl) return;
    const done = h("button", "go"); done.textContent = "Done";
    done.onclick = () => stop();
    barEl = h("div", "glass bar", h("span", "dot"),
      Object.assign(h("span"), { textContent: "Zapper" }),
      Object.assign(h("span", "dim"), { textContent: "Click an element to hide it   ↑ bigger   ↓ smaller   Esc to finish" }), done);
    root.append(barEl);
  }

  function toast(entry, text) {
    ensureUI();
    clearTimeout(toastTimer);
    if (toastEl) toastEl.remove();
    const n = session.length;
    const msg = h("span", "", entry ? "Hidden " : "", entry ? Object.assign(h("b"), { textContent: entry.label }) : "");
    if (!entry) msg.textContent = text;
    const kids = [h("span", "dot"), msg];
    if (entry) {
      if (n > 1) kids.push(Object.assign(h("span", "dim"), { textContent: n + " this visit" }));
      const undo = h("button"); undo.textContent = "Undo";
      undo.onclick = () => { undoEntry(entry); };
      if (entry.savedId) {
        kids.push(Object.assign(h("span", "dim"), { textContent: "Saved for " + (entry.savedHost || hostName) }));
      } else {
        const save = h("button", "go"); save.textContent = "Save rule";
        save.onclick = () => saveEntry(entry);
        kids.push(save);
      }
      kids.push(undo);
    }
    toastEl = h("div", "glass toast", ...kids);
    toastEl.addEventListener("mouseenter", () => clearTimeout(toastTimer));
    root.append(toastEl);
    // when the picker isn't open the toast tidies itself away; while picking it stays for the next zap
    toastTimer = setTimeout(() => { if (toastEl) { toastEl.remove(); toastEl = null; } if (!Z.active) dropUI(); }, entry ? 9000 : 3500);
  }

  async function saveEntry(entry) {
    const r = await send({ type: "zapSave", sel: entry.sel, unlock: entry.unlock });
    if (r && r.ok) { entry.savedId = r.id; entry.savedHost = r.host; toast(entry); }
    else toast(null, (r && r.error) || "Couldn't save the rule.");
  }
  function undoEntry(entry) {
    const i = session.indexOf(entry);
    if (i >= 0) session.splice(i, 1);
    renderSession();
    if (entry.savedId) send({ type: "zapDelete", host: entry.savedHost || hostName, id: entry.savedId });
    toast(null, "Brought it back.");
  }

  // ---------------------------------------------------------------------------------------------------------
  // 4. Zapping
  // ---------------------------------------------------------------------------------------------------------
  function zap(el) {
    if (!el || !el.isConnected || el === document.documentElement || el === document.body) return;
    const sel = buildSelector(el);
    if (!sel) { ensureUI(); toast(null, "That element is too complicated to hide reliably."); return; }
    ensureUI();
    const r = el.getBoundingClientRect();
    const poof = h("div", "poof");
    poof.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;`;
    root.append(poof);
    setTimeout(() => poof.remove(), 500);
    const entry = { sel, unlock: lockedScroll(el), label: describe(el), savedId: "", savedHost: "" };
    session.push(entry);
    renderSession();                       // it is gone now
    if (autoSave) saveEntry(entry); else toast(entry);
  }

  // ---------------------------------------------------------------------------------------------------------
  // 5. The picker
  // ---------------------------------------------------------------------------------------------------------
  let hover = null, trail = [], lastX = 0, lastY = 0;
  const fromUI = (e) => { try { return !!hostEl && e.composedPath().includes(hostEl); } catch (err) { return false; } };

  function highlight(el) {
    hover = el;
    if (!el || !boxEl) { if (boxEl) { boxEl.hidden = true; tagEl.hidden = true; } return; }
    const r = el.getBoundingClientRect();
    boxEl.hidden = tagEl.hidden = false;
    boxEl.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;`;
    tagEl.textContent = `${describe(el)}  ${Math.round(r.width)}×${Math.round(r.height)}`;
    tagEl.style.left = Math.max(6, Math.min(r.left, innerWidth - 200)) + "px";
    // above the element if there is room, else below it, else tucked inside its top-left corner (full-page overlays)
    tagEl.style.top = (r.top > 30 ? r.top - 28 : (r.bottom < innerHeight - 40 ? r.bottom + 6 : Math.max(r.top, 0) + 70)) + "px";
  }
  function targetAt(x, y) {
    const el = document.elementFromPoint(x, y);
    return (!el || el === hostEl || el === document.documentElement || el === document.body) ? null : el;
  }

  const onMove = (e) => {
    if (fromUI(e)) return;
    if (Math.abs(e.clientX - lastX) + Math.abs(e.clientY - lastY) < 3) return;   // arrow-key selection stays put
    lastX = e.clientX; lastY = e.clientY; trail = [];
    highlight(targetAt(e.clientX, e.clientY));
  };
  const swallow = (e) => { if (fromUI(e)) return; e.preventDefault(); e.stopImmediatePropagation(); };
  const onClick = (e) => {
    if (fromUI(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    zap(hover && hover.isConnected ? hover : targetAt(e.clientX, e.clientY));
    trail = []; highlight(null);
  };
  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); stop(); }
    else if (e.key === "ArrowUp" && hover) {
      e.preventDefault(); e.stopImmediatePropagation();
      const p = hover.parentElement;
      if (p && p !== document.body && p !== document.documentElement) { trail.push(hover); highlight(p); }
    } else if (e.key === "ArrowDown" && trail.length) {
      e.preventDefault(); e.stopImmediatePropagation(); highlight(trail.pop());
    } else if ((e.key === "Enter" || e.key === " ") && hover) {
      e.preventDefault(); e.stopImmediatePropagation(); zap(hover); trail = []; highlight(null);
    }
  };
  const onScroll = () => { if (hover) highlight(hover); };
  const MOUSE = ["mousedown", "mouseup", "pointerdown", "pointerup", "touchstart", "touchend", "dblclick", "auxclick"];

  async function start() {
    if (Z.active) return;
    try { const { settings } = await chrome.storage.local.get("settings"); autoSave = !!(settings && settings.zapAutoSave); } catch (e) {}
    Z.active = true;
    showBar();
    window.addEventListener("mousemove", onMove, true);
    window.addEventListener("click", onClick, true);
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("scroll", onScroll, true);
    for (const t of MOUSE) window.addEventListener(t, swallow, true);
    document.documentElement.style.setProperty("cursor", "crosshair", "important");
  }
  function stop() {
    if (!Z.active) { if (hostEl) dropUI(); return; }
    Z.active = false;
    window.removeEventListener("mousemove", onMove, true);
    window.removeEventListener("click", onClick, true);
    window.removeEventListener("keydown", onKey, true);
    window.removeEventListener("scroll", onScroll, true);
    for (const t of MOUSE) window.removeEventListener(t, swallow, true);
    document.documentElement.style.removeProperty("cursor");
    hover = null; trail = [];
    if (barEl) { barEl.remove(); barEl = null; }
    if (boxEl) { boxEl.hidden = true; tagEl.hidden = true; }
    if (toastEl) toast(session[session.length - 1] || null, "Zapper closed.");   // keep Save / Undo reachable for a few seconds
    else dropUI();
  }

  async function zapLast() {
    try { const { settings } = await chrome.storage.local.get("settings"); autoSave = !!(settings && settings.zapAutoSave); } catch (e) {}
    const el = window.__icLastCtx;
    if (el && el.isConnected) zap(el); else start();      // nothing remembered (page opened before the update): pick instead
  }

  Z.start = start; Z.stop = stop;
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== "zap") return;
      if (msg.mode === "last") zapLast();
      else if (msg.mode === "toggle") (Z.active ? stop() : start());
      else if (msg.mode === "stop") stop();
      else start();
    });
  } catch (e) {}
})();
