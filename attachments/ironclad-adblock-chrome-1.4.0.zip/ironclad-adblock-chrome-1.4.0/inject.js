// inject.js - popup / redirect guard. Runs in the PAGE's own JavaScript world
// (manifest: "world": "MAIN").
//
// Why this file exists: in 1.2.x the window.open / location guards lived in content.js,
// which runs in Chrome's isolated world. Page scripts never see anything a content script
// overrides there, so popups and redirects were never actually intercepted.
// This file has no access to chrome.* APIs; it only talks to content.js through DOM events.
(() => {
  if (window.__icGuard) return;
  try { Object.defineProperty(window, "__icGuard", { value: true }); } catch (e) { return; }

  const EV_REPORT = "__ic_report";  // page world  -> content.js : something was blocked
  const EV_CFG = "__ic_cfg";        // content.js  -> page world  : {on: bool}
  const EV_ALLOW = "__ic_allow";    // content.js  -> page world  : user chose "Continue" for a redirect
  const EV_READY = "__ic_ready";    // page world  -> content.js  : listeners are installed

  let on = true;                    // content.js switches this off when blocking is off / site is paused
  const allowedOnce = new Set();    // URLs the user explicitly chose to continue to
  const realOpen = window.open;

  // Rough "same site" test (registrable domain approximation).
  const SLD = new Set(["co", "com", "org", "net", "gov", "edu", "ac"]);
  function site(h) {
    const l = String(h || "").toLowerCase().replace(/\.$/, "").split(".");
    if (l.length <= 2) return l.join(".");
    const n = (l[l.length - 1].length === 2 && SLD.has(l[l.length - 2])) ? 3 : 2;
    return l.slice(-n).join(".");
  }
  const mySite = site(location.hostname);
  const isWeb = (u) => u.protocol === "http:" || u.protocol === "https:";
  const parse = (url) => { try { return new URL(String(url), location.href); } catch (e) { return null; } };
  const activated = () => {
    try { return !!(navigator.userActivation && navigator.userActivation.isActive); } catch (e) { return false; }
  };
  function report(kind, url) {
    try {
      document.dispatchEvent(new CustomEvent(EV_REPORT, { detail: JSON.stringify({ kind, url: String(url || "") }) }));
    } catch (e) {}
  }

  // ---- window.open ---------------------------------------------------------------------
  // A popup the user did not just ask for (no click / key press behind it) that points to
  // another site or to a blank page is almost always an ad. Real user-triggered popups
  // (login windows, "share" buttons) are left alone; listed ad domains are still caught by
  // the network rules.
  window.open = function open(url, target, features) {
    try {
      if (on && !activated()) {
        const empty = url === undefined || url === null || String(url).trim() === "";
        const u = empty ? null : parse(url);
        const blank = empty || (u && u.href === "about:blank");
        const script = u && /^(javascript|data|vbscript):$/i.test(u.protocol);
        const external = u && isWeb(u) && site(u.hostname) !== mySite;
        if (blank || script || external) {
          report("open", external ? u.href : "");
          return null;               // same result as Chrome's own popup blocker
        }
      }
    } catch (e) {}
    return realOpen.apply(this, arguments);
  };

  // ---- scripted redirects of this tab ---------------------------------------------------
  // location.assign / replace / href are not overridable in Chrome, so use the Navigation API,
  // which fires for every script-started navigation and can be cancelled.
  try {
    if (window === window.top && window.navigation && typeof navigation.addEventListener === "function") {
      navigation.addEventListener("navigate", (e) => {
        try {
          if (!on || !e.cancelable || e.userInitiated || e.hashChange || e.downloadRequest != null) return;
          if (e.navigationType === "traverse" || e.navigationType === "reload") return;
          const u = parse(e.destination && e.destination.url);
          if (!u || !isWeb(u) || site(u.hostname) === mySite) return;
          if (allowedOnce.has(u.href)) { allowedOnce.delete(u.href); return; }
          if (activated()) return;   // follows a real click: leave it to the network rules
          e.preventDefault();
          report("redirect", u.href);
        } catch (err) {}
      });
    }
  } catch (e) {}

  document.addEventListener(EV_CFG, (e) => {
    try { on = !!JSON.parse(e.detail).on; } catch (err) {}
  });
  document.addEventListener(EV_ALLOW, (e) => {
    try {
      const u = parse(e.detail);
      if (u && isWeb(u)) { allowedOnce.add(u.href); location.assign(u.href); }
    } catch (err) {}
  });
  try { document.dispatchEvent(new CustomEvent(EV_READY)); } catch (e) {}
})();
