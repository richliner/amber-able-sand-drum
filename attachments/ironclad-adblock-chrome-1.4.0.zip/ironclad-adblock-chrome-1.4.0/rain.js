// rain.js - the pink falling 0s and 1s behind the glass (popup background). Quiet on purpose: low opacity,
// ~14 frames a second, paused when the popup is hidden, and a still frame for people who ask for less motion.
(() => {
  const cv = document.getElementById("rain");
  if (!cv) return;
  const g = cv.getContext("2d");
  const COLORS = ["255,95,176", "255,140,200", "214,90,255"];     // pink, light pink, a little violet to blend into the glow
  let cols = [], w = 0, h = 0, size = 15;
  function resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    w = cv.clientWidth; h = cv.clientHeight;
    cv.width = w * dpr; cv.height = h * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.ceil(w / size);
    cols = Array.from({ length: n }, (_, i) => cols[i] || { y: Math.random() * h, v: 0.5 + Math.random() * 1.1, c: COLORS[(Math.random() * COLORS.length) | 0] });
    g.font = `600 ${size - 2}px ui-monospace, "SF Mono", Menlo, Consolas, monospace`;
  }
  function frame() {
    g.globalCompositeOperation = "destination-out";            // fade old digits out so the canvas stays transparent
    g.fillStyle = "rgba(0,0,0,.16)"; g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = "source-over";
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      g.fillStyle = `rgba(${c.c},.95)`;
      g.fillText(Math.random() < .5 ? "0" : "1", i * size, c.y);
      c.y += size * c.v;
      if (c.y > h + 40 && Math.random() > .975) { c.y = -10; c.v = 0.5 + Math.random() * 1.1; }
    }
  }
  resize();
  addEventListener("resize", resize);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
    for (let i = 0; i < 40; i++) frame();                        // one still frame
    return;
  }
  setInterval(() => { if (!document.hidden) frame(); }, 70);
})();
