const $ = (id) => document.getElementById(id);
let siteHost = "", tabUrl = "", tabId = null, pollT = null;

const send = (msg) => new Promise((res) => chrome.runtime.sendMessage(msg, res));
const normalize = (h) => (h || "").toLowerCase().replace(/^www\./, "");

const STATUS = {
  connected: ["Connected to IronCladOS", "ok"],
  pairing: ["Waiting for you to approve it in the IronCladOS window…", "warn"],
  offline: ["IronCladOS isn't running", "warn"],
  denied: ["Declined in IronCladOS", "warn"],
  error: ["Connection error", "warn"],
  unpaired: ["Not connected", "muted"],
};

function render(st) {
  if (!st || st.error) { $("status").textContent = (st && st.error) || "Could not reach the extension."; return; }
  const L = st.link || {}, managed = !!st.managed;

  // header
  $("enabled").checked = st.enabled;
  $("enabled").disabled = managed;
  $("status").textContent = st.enabled ? `On · ${st.applied.total.toLocaleString()} domains blocked` : "Off";
  const ap = st.applied || {};
  const problem = ap.error ? "Rule error: " + ap.error
    : (ap.dropped ? `${ap.dropped.toLocaleString()} domains were rejected by Chrome and are NOT being blocked${ap.sample ? " (for example " + ap.sample + ")" : ""}.` : "");
  $("gerr").textContent = problem; $("gerr").hidden = !problem;     // visible in managed mode too
  $("banner").hidden = !managed;
  $("banner").textContent = st.notice ? "🔒 " + st.notice : "🔒 Managed by IronCladOS — change settings in the app. Switches here are locked.";

  // zapper card
  $("zapsw").checked = st.zapper !== false;
  $("zapsw").disabled = managed;
  $("zapsave").checked = !!st.zapAutoSave;
  $("zapstart").disabled = st.zapper === false;
  $("zapstart").textContent = st.zapper === false ? (managed ? "Turned off in IronCladOS" : "Zapper is off") : "Pick an element";
  liveBadge = st.badgeLive !== false;

  // site card
  $("warn").checked = st.warn;
  $("warn").disabled = managed;
  $("yflash").checked = st.ytFlash !== false;
  $("yflash").disabled = managed;
  const allowed = siteHost && st.allow.some((d) => siteHost === d || siteHost.endsWith("." + d));
  $("pause").textContent = allowed ? "Resume on this site" : "Pause on this site";
  $("pause").disabled = !siteHost || managed;

  // app link card
  const [text, cls] = (L.paired && L.status === "offline") ? ["Paired · IronCladOS isn't running (using last synced settings)", "warn"] : (STATUS[L.status] || STATUS.unpaired);
  const stat = $("linkstat");
  stat.className = cls; stat.textContent = text + (L.status === "connected" && L.domains ? ` · ${L.domains.toLocaleString()} domains` : "");
  $("lerr").textContent = L.status === "connected" ? "" : (L.error || "");
  $("lconnect").hidden = !!L.paired; $("lconnect").disabled = L.status === "pairing";
  $("lsync").hidden = !L.paired; $("lscan").hidden = !(L.paired && L.status === "connected");
  // only the app may disconnect; if it's unreachable you can disconnect here so you're never stuck
  $("ldisc").hidden = !(L.paired && L.status !== "connected");
  $("adv").hidden = managed && L.status === "connected";
  if (document.activeElement !== $("lport")) $("lport").value = L.port || 8898;

  // blocklists: own catalog when standalone, app-managed message when paired
  $("listscard").hidden = managed; $("managedlists").hidden = !managed;
  $("appdomains").textContent = L.domains ? `${L.domains.toLocaleString()} domains from the app are active.` : "Waiting for the app's lists…";
  $("err").textContent = problem;
  $("msg").textContent = st.updating ? "Updating…" : (st.message || "");
  $("update").disabled = st.updating;
  $("lists").replaceChildren(...st.lists.map((l) => {
    const row = document.createElement("label"); row.className = "l";
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.className = "cb"; cb.checked = l.enabled;
    cb.onchange = async () => render(await send({ type: "toggleList", id: l.id }));
    const name = document.createElement("span"); name.textContent = l.name;
    const count = document.createElement("span"); count.className = "count";
    count.textContent = l.count ? l.count.toLocaleString() : (l.enabled ? "pending" : "");
    row.append(cb, name, count); return row;
  }));

  // allowlist: read-only when managed
  $("addrow").hidden = managed;
  $("allow").replaceChildren(...(st.allow.length ? st.allow.map((d) => {
    const row = document.createElement("div"); row.className = "chip";
    const t = document.createElement("span"); t.textContent = d; row.append(t);
    if (!managed) {
      const x = document.createElement("a"); x.textContent = "remove";
      x.onclick = async () => render(await send({ type: "unallow", host: d }));
      row.append(x);
    }
    return row;
  }) : [Object.assign(document.createElement("div"), { className: "muted", textContent: "No sites paused." })]));

  clearTimeout(pollT);
  if (L.status === "pairing") pollT = setTimeout(async () => render(await send({ type: "state" })), 1500);
}

function showScan(res) {
  const box = $("scanres"); box.replaceChildren();
  if (!res || res.error) { box.append(Object.assign(document.createElement("div"), { className: "err", textContent: (res && res.error) || "No answer from the app." })); return; }
  const colour = { danger: "var(--red)", warn: "var(--amber)", caution: "var(--amber)" }[res.level] || "var(--green)";
  const head = document.createElement("div"); head.style.color = colour; head.style.fontWeight = "600";
  head.textContent = `${res.verdict} · ${res.score}/100`;
  box.append(head);
  if (res.findings && res.findings.length) {
    const ul = document.createElement("ul");
    for (const f of res.findings.slice(0, 4)) { const li = document.createElement("li"); li.textContent = f.reason; ul.append(li); }
    box.append(ul);
  }
}

// ---- live counter ----------------------------------------------------------------------------------------
let liveBadge = true, shownTotal = 0, tweenRaf = 0;
function tweenCount(to) {
  const el = $("count"), from = shownTotal;
  cancelAnimationFrame(tweenRaf);
  shownTotal = to;
  if (from === to) { el.textContent = to.toLocaleString(); return; }
  if (from < to) { el.classList.remove("pulse"); void el.offsetWidth; el.classList.add("pulse"); }   // a block just happened: pop + pink glow
  const t0 = performance.now(), dur = Math.min(700, 220 + (to - from) * 12);
  const tick = (t) => {
    const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = Math.round(from + (to - from) * e).toLocaleString();
    if (k < 1) tweenRaf = requestAnimationFrame(tick);
  };
  tweenRaf = requestAnimationFrame(tick);
}
function showStats(st) {
  if (!st) return;
  if (liveBadge) tweenCount(st.total);
  $("c-net").textContent = st.net.toLocaleString();
  $("c-popup").textContent = st.popup.toLocaleString();
  $("c-yt").textContent = st.yt.toLocaleString();
  $("c-cos").textContent = st.cos.toLocaleString();
  $("c-zap").textContent = st.zap.toLocaleString();
}
// A packed install can't see individual blocks: show Chrome's own badge text and refresh it while the popup is open.
async function readBadge() {
  if (liveBadge || tabId == null) return;
  try { $("count").textContent = (await chrome.action.getBadgeText({ tabId })) || "0"; } catch (e) {}
}

// ---- zapper card -----------------------------------------------------------------------------------------
async function renderZaps() {
  const box = $("zaplist");
  if (!tabUrl || !/^https?:/i.test(tabUrl)) { box.replaceChildren(); $("zhead").hidden = true; return; }
  const { rules = [] } = (await send({ type: "zapList", url: tabUrl })) || {};
  $("zhead").hidden = !rules.length;
  $("zcount").textContent = `Saved for this site (${rules.length})`;
  $("zclear").hidden = rules.length < 2;
  box.replaceChildren(...rules.map((r) => {
    const row = document.createElement("div"); row.className = "rule";
    const code = document.createElement("code"); code.textContent = r.sel; code.title = r.sel + (r.host !== siteHost ? `  (rule for ${r.host})` : "");
    const x = document.createElement("a"); x.textContent = "remove";
    x.onclick = async () => { await send({ type: "zapDelete", host: r.host, id: r.id }); renderZaps(); };
    row.append(code, x); return row;
  }));
}

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { siteHost = normalize(new URL(tab.url).hostname); tabUrl = tab.url; } catch (e) {}
  $("site").textContent = siteHost || "—";
  if (tab && tab.id != null) {
    tabId = tab.id;
    showStats(await send({ type: "tabStats", tabId }));       // then the background pushes every change while the popup is open
    try {
      const port = chrome.runtime.connect({ name: "popup" });
      port.onMessage.addListener((m) => { if (m && m.type === "stats" && m.tabId === tabId) showStats(m.stats); });
    } catch (e) {}
    setInterval(readBadge, 1000);
  }
  renderZaps();

  $("enabled").onchange = async (e) => render(await send({ type: "enable", value: e.target.checked }));
  $("warn").onchange = async (e) => render(await send({ type: "setWarn", value: e.target.checked }));
  $("yflash").onchange = async (e) => render(await send({ type: "setYtFlash", value: e.target.checked }));
  $("zapsw").onchange = async (e) => render(await send({ type: "setZapper", value: e.target.checked }));
  $("zapsave").onchange = async (e) => render(await send({ type: "setZapSave", value: e.target.checked }));
  $("zapstart").onclick = async () => {
    if (tabId == null) return;
    const r = await send({ type: "zapStart", tabId, mode: "pick" });
    if (r && r.ok) { window.close(); return; }            // the picker is on the page now: get out of its way
    $("zaperr").textContent = (r && r.error) || "Couldn't start the Zapper."; $("zaperr").hidden = false;
  };
  $("zclear").onclick = async () => {
    const { rules = [] } = (await send({ type: "zapList", url: tabUrl })) || {};
    for (const h of new Set(rules.map((r) => r.host))) await send({ type: "zapClear", host: h });
    renderZaps();
  };
  $("update").onclick = async () => { $("msg").textContent = "Updating…"; $("update").disabled = true; render(await send({ type: "update" })); };
  $("pause").onclick = async () => {
    const st = await send({ type: "state" });
    const hit = st.allow.find((d) => siteHost === d || siteHost.endsWith("." + d));
    render(await send({ type: hit ? "unallow" : "allow", host: hit || siteHost }));
    if (tab && tab.id != null) chrome.tabs.reload(tab.id);
  };
  $("add").onclick = async () => { const v = $("newhost").value; $("newhost").value = ""; render(await send({ type: "allow", host: v })); };

  $("lconnect").onclick = async () => render(await send({ type: "linkPair" }));
  $("lsync").onclick = async () => { $("lsync").disabled = true; render(await send({ type: "linkSync" })); $("lsync").disabled = false; };
  $("ldisc").onclick = async () => render(await send({ type: "linkUnpair" }));
  $("lportset").onclick = async () => render(await send({ type: "linkPort", value: $("lport").value }));
  $("lscan").onclick = async () => {
    if (!/^https?:/i.test(tabUrl)) return showScan({ error: "Open a normal web page first." });
    $("scanres").textContent = "Scanning…";
    showScan(await send({ type: "scan", url: tabUrl }));
  };
  render(await send({ type: "state" }));
})();
