// badge.js - live, animated block counter on the toolbar icon (loaded by background.js with importScripts).
//
// What you see: every time something is blocked on the tab you are looking at, the number on the icon counts
// up to the new value in a few quick steps, the badge flashes bright and fades back to teal, and a thin ring
// pulses around the icon. Big jumps (a page firing 40 tracker requests at once) count up smoothly instead of
// jumping, and the whole thing is frame-limited so a noisy page cannot make the toolbar flicker.
//
// Where the numbers come from (per tab, reset when the tab loads a new page):
//   net    requests blocked by the network rules   (needs onRuleMatchedDebug, i.e. an unpacked install)
//   popup  pop-ups / scripted redirects stopped     (inject.js -> content.js -> here)
//   yt     YouTube ads removed or skipped            (yt.js / the skipper)
//   cos    ad slots hidden on the page               (shown in the popup, not in the badge)
//   zap    page elements hidden by your Zapper rules (shown in the popup, not in the badge)
// The badge shows net + popup + yt.
//
// A packed (Web Store style) install cannot see individual rule matches. There Chrome keeps the badge text
// itself and this file only adds the pulse whenever that text changes.

const IcBadge = (() => {
  const BASE = [15, 184, 164];            // #0fb8a4, the IronClad teal
  const FLASH = [255, 255, 255];
  const TEXT_COLOR = "#04201c";
  const FRAME_MS = 55;                    // animation frame length
  const HEAT_DECAY = 0.30;                // how fast the flash fades per frame
  const RING_GAP_MS = 900;                // at most one icon ring per this many ms
  const POLL_MS = 450;                    // packed-install fallback: how often the badge text is checked
  const POLL_WINDOW_MS = 8000;            // ... and for how long after the last sign of activity

  // ---- pure helpers (unit-tested in tests/) -------------------------------------------------------------
  function fmt(n) {
    n = Math.max(0, Math.floor(Number(n) || 0));
    if (n === 0) return "";
    if (n < 1000) return String(n);
    if (n < 10000) return (Math.floor(n / 100) / 10).toFixed(1).replace(/\.0$/, "") + "k";
    if (n < 1000000) return Math.floor(n / 1000) + "k";
    return "1M+";
  }
  const hex = (c) => "#" + c.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
  function mix(a, b, t) { return a.map((v, i) => v + (b[i] - v) * t); }
  const colorFor = (heat) => hex(mix(BASE, FLASH, Math.max(0, Math.min(1, heat))));
  // One animation step: how many to show next and how hot the flash is. Count-up eases out (each frame closes a
  // third of the gap), so even a jump of 40 settles in about 8 frames, under half a second; the flash restarts at
  // full heat whenever the number moves.
  function nextFrame(shown, target, heat) {
    if (shown > target) return { shown: target, heat: 0 };
    if (shown < target) return { shown: shown + Math.max(1, Math.ceil((target - shown) / 3)), heat: 1 };
    return { shown, heat: Math.max(0, heat - HEAT_DECAY) };
  }
  const total = (s) => s.net + s.popup + s.yt;

  // ---- state --------------------------------------------------------------------------------------------
  const tabs = new Map();                 // tabId -> state
  const activeByWindow = new Map();       // windowId -> active tabId
  const ports = new Set();                // open popups
  let own = false;                        // true when we can count rule matches ourselves
  let ringBroken = false, ringFrames = null, lastRing = 0;
  let persistTimer = 0, pushTimers = new Map();

  function blank() {
    return { net: 0, popup: 0, yt: 0, cos: new Map(), zap: new Map(), shown: 0, heat: 0, timer: 0, recent: [], lastPaint: 0 };
  }
  const get = (tabId) => { let s = tabs.get(tabId); if (!s) { s = blank(); tabs.set(tabId, s); } return s; };
  const sumMap = (m) => { let n = 0; for (const v of m.values()) n += v; return n; };
  function publicStats(s) {
    return { net: s.net, popup: s.popup, yt: s.yt, cos: sumMap(s.cos), zap: sumMap(s.zap), total: total(s) };
  }
  const isActive = (tabId) => { for (const t of activeByWindow.values()) if (t === tabId) return true; return false; };

  // ---- painting -----------------------------------------------------------------------------------------
  function paint(tabId, s) {
    const text = fmt(s.shown);
    chrome.action.setBadgeText({ tabId, text }).catch(() => {});
    if (text) {
      chrome.action.setBadgeBackgroundColor({ tabId, color: colorFor(s.heat) }).catch(() => {});
      if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ tabId, color: TEXT_COLOR }).catch(() => {});
    }
    s.lastPaint = Date.now();
  }

  function step(tabId) {
    const s = tabs.get(tabId);
    if (!s) return;
    s.timer = 0;
    const target = total(s);
    const prevHeat = s.heat;
    const f = nextFrame(s.shown, target, s.heat);
    s.shown = f.shown; s.heat = f.heat;
    if (f.heat === 1 && prevHeat < 0.5) ring(tabId);
    paint(tabId, s);
    if (s.shown < target || s.heat > 0) s.timer = setTimeout(() => step(tabId), FRAME_MS);
  }

  // Called whenever a tab's numbers changed.
  function changed(tabId) {
    const s = get(tabId);
    const target = total(s);
    if (own) {
      if (isActive(tabId) && target > s.shown) {
        if (!s.timer) s.timer = setTimeout(() => step(tabId), 0);       // animate the tab you are looking at
      } else if (!s.timer) {
        s.shown = target; s.heat = 0; paint(tabId, s);                  // background tab: just set the number
      }
    }
    push(tabId);
    persistSoon();
  }

  // ---- icon ring ----------------------------------------------------------------------------------------
  async function buildRing() {
    const blob = await (await fetch(chrome.runtime.getURL("icons/48.png"))).blob();
    const bmp = await createImageBitmap(blob);
    const out = [];
    for (let i = 0; i < 5; i++) {
      const frame = {};
      for (const sz of [16, 32]) {
        const c = new OffscreenCanvas(sz, sz), g = c.getContext("2d");
        const k = i / 4;                                     // 0 -> 1 as the ring grows and fades
        const scale = 0.80 + 0.20 * k;                       // the shield "breathes" out to full size
        const w = sz * scale;
        g.drawImage(bmp, (sz - w) / 2, (sz - w) / 2, w, w);
        if (i < 4) {
          g.beginPath();
          g.arc(sz / 2, sz / 2, sz * (0.30 + 0.20 * k), 0, Math.PI * 2);
          g.lineWidth = Math.max(1, sz / 12);
          g.strokeStyle = `rgba(126, 245, 228, ${(1 - k).toFixed(2)})`;
          g.stroke();
        }
        frame[sz] = g.getImageData(0, 0, sz, sz);
      }
      out.push(frame);
    }
    return out;
  }
  async function ring(tabId) {
    const now = Date.now();
    if (ringBroken || now - lastRing < RING_GAP_MS || !isActive(tabId)) return;
    lastRing = now;
    try {
      if (!ringFrames) ringFrames = await buildRing();
      for (let i = 0; i < ringFrames.length; i++) {
        await chrome.action.setIcon({ tabId, imageData: ringFrames[i] });
        await new Promise((r) => setTimeout(r, 70));
      }
      await chrome.action.setIcon({ tabId, path: { 16: "icons/16.png", 48: "icons/48.png", 128: "icons/128.png" } });
    } catch (e) {
      ringBroken = true;                                      // e.g. the tab closed mid-animation, or no OffscreenCanvas
    }
  }

  // ---- counting -----------------------------------------------------------------------------------------
  function add(tabId, kind, n = 1) {
    if (!(tabId >= 0) || !(kind in { net: 1, popup: 1, yt: 1 })) return;
    const s = get(tabId);
    s[kind] += n;
    s.recent.push([Date.now(), kind, n]);
    if (s.recent.length > 60) s.recent.splice(0, s.recent.length - 60);
    changed(tabId);
  }
  function setMax(tabId, kind, frameId, n) {                  // per-frame maximum (cos / zap): hidden things never "un-count"
    if (!(tabId >= 0) || !(kind === "cos" || kind === "zap")) return;
    const s = get(tabId), m = s[kind];
    if ((m.get(frameId) || 0) >= n) return;
    m.set(frameId, n);
    push(tabId);
    persistSoon();
  }
  // A top-level page just started: forget the old page's numbers. Blocks that were counted at or after the new
  // document's own start time (performance.timeOrigin, sent by content.js) belong to the new page: those requests
  // fired before this content script got to run. Anything earlier belongs to the page you just left.
  function pageStart(tabId, startedAt) {
    if (!(tabId >= 0)) return;
    const s = get(tabId), cutoff = Number(startedAt) > 0 ? Number(startedAt) : Date.now();
    const keep = s.recent.filter((r) => r[0] >= cutoff);
    s.net = s.popup = s.yt = 0; s.cos.clear(); s.zap.clear(); s.recent = [];
    for (const [t, kind, n] of keep) { s[kind] += n; s.recent.push([t, kind, n]); }
    clearTimeout(s.timer); s.timer = 0;
    s.shown = total(s); s.heat = 0;
    if (own) paint(tabId, s);
    push(tabId);
    persistSoon();
  }
  function forget(tabId) {
    const s = tabs.get(tabId);
    if (s) clearTimeout(s.timer);
    tabs.delete(tabId);
    persistSoon();
  }

  // ---- popup live link ----------------------------------------------------------------------------------
  function push(tabId) {
    if (!ports.size || pushTimers.has(tabId)) return;
    pushTimers.set(tabId, setTimeout(() => {
      pushTimers.delete(tabId);
      const s = tabs.get(tabId);
      if (!s) return;
      const msg = { type: "stats", tabId, stats: publicStats(s) };
      for (const p of ports) { try { p.postMessage(msg); } catch (e) { ports.delete(p); } }
    }, 80));
  }
  function attachPort(port) {
    ports.add(port);
    port.onDisconnect.addListener(() => ports.delete(port));
  }
  const stats = (tabId) => publicStats(get(tabId));

  // ---- survive service-worker restarts -------------------------------------------------------------------
  function persistSoon() {
    if (persistTimer || !chrome.storage.session) return;
    persistTimer = setTimeout(() => {
      persistTimer = 0;
      const o = {};
      for (const [id, s] of tabs) o[id] = { net: s.net, popup: s.popup, yt: s.yt, cos: [...s.cos], zap: [...s.zap] };
      chrome.storage.session.set({ icTabStats: o }).catch(() => {});
    }, 700);
  }
  async function restore() {
    try {
      const { icTabStats } = await chrome.storage.session.get("icTabStats");
      for (const [id, o] of Object.entries(icTabStats || {})) {
        if (tabs.has(+id)) continue;
        const s = blank();
        s.net = o.net | 0; s.popup = o.popup | 0; s.yt = o.yt | 0;
        s.cos = new Map(o.cos || []); s.zap = new Map(o.zap || []);
        s.shown = total(s);
        tabs.set(+id, s);
      }
    } catch (e) {}
  }

  // ---- packed-install fallback: Chrome owns the badge text, we only watch it and pulse -------------------
  let pollUntil = 0, pollTimer = 0, lastText = new Map();
  function pollOpen() {
    pollUntil = Date.now() + POLL_WINDOW_MS;
    if (!pollTimer) pollTimer = setTimeout(pollTick, POLL_MS);
  }
  async function pollTick() {
    pollTimer = 0;
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab && tab.id >= 0) {
        const text = await chrome.action.getBadgeText({ tabId: tab.id });
        const prev = lastText.get(tab.id);
        lastText.set(tab.id, text);
        if (text && prev !== undefined && text !== prev) {
          chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#ffffff" }).catch(() => {});
          if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ tabId: tab.id, color: TEXT_COLOR }).catch(() => {});
          ring(tab.id);
          for (const [i, h] of [0.65, 0.35, 0.12, 0].entries()) {
            setTimeout(() => chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: colorFor(h) }).catch(() => {}), 70 * (i + 1));
          }
        }
        if (lastText.size > 50) lastText.delete(lastText.keys().next().value);
      }
    } catch (e) {}
    if (Date.now() < pollUntil) pollTimer = setTimeout(pollTick, POLL_MS);
  }

  // ---- wiring -------------------------------------------------------------------------------------------
  function init() {
    const dnr = chrome.declarativeNetRequest;
    own = !!(dnr && dnr.onRuleMatchedDebug);
    try { dnr.setExtensionActionOptions({ displayActionCountAsBadgeText: !own }); } catch (e) {}
    chrome.action.setBadgeBackgroundColor({ color: hex(BASE) }).catch(() => {});
    if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: TEXT_COLOR }).catch(() => {});
    if (own) {
      dnr.onRuleMatchedDebug.addListener((info) => {
        const id = info && info.rule && info.rule.ruleId;
        const tabId = info && info.request && info.request.tabId;
        if (id >= 100 && tabId >= 0) add(tabId, "net");        // ids 1-49 are allow rules; 100+ block / warn
      });
    }
    chrome.tabs.query({ active: true }).then((list) => { for (const t of list) activeByWindow.set(t.windowId, t.id); }).catch(() => {});
    chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
      activeByWindow.set(windowId, tabId);
      const s = tabs.get(tabId);
      if (own && s) { s.shown = total(s); s.heat = 0; paint(tabId, s); }
    });
    chrome.tabs.onRemoved.addListener((tabId) => forget(tabId));
    chrome.tabs.onReplaced.addListener((added, removed) => { const s = tabs.get(removed); if (s) { tabs.set(added, s); } forget(removed); });
    if (!own) chrome.tabs.onUpdated.addListener((id, info) => { if (info.status) pollOpen(); });
    return restore();
  }

  return { init, add, setMax, pageStart, forget, attachPort, stats, pollOpen,
           get own() { return own; }, _t: { fmt, nextFrame, colorFor, total } };
})();

if (typeof module !== "undefined") module.exports = IcBadge;
