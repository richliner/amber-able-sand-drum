// yt.js - stops YouTube from scheduling video ads at all (runs in the page's own JS world,
// YouTube domains only). The ad schedule travels inside the player response as the keys
// adPlacements / playerAds / adSlots; removing them before the player reads them means no ad
// stream is requested, so there is no black "waiting for the ad" screen to skip.
// content.js is the fallback for anything that still gets through.
(() => {
  if (window.__icYt) return;
  try { Object.defineProperty(window, "__icYt", { value: true }); } catch (e) { return; }

  let on = true;                                    // content.js can switch this off (see __ic_cfg)
  const KEYS = ["adPlacements", "playerAds", "adSlots", "adBreakHeartbeatParams", "adBreakParams"];

  // content.js shows the "Ad skipped" screen when this fires (only when real ads were scheduled, not for every video)
  function announce() { try { document.dispatchEvent(new CustomEvent("__ic_ad_blocked")); } catch (e) {} }

  function pruneObj(o) {
    if (!o || typeof o !== "object") return;
    let hadAds = false;
    for (const k of KEYS) {
      if (!(k in o)) continue;
      if ((k === "adPlacements" || k === "playerAds") && Array.isArray(o[k]) && o[k].length) hadAds = true;
      try { delete o[k]; } catch (e) {}
    }
    if (hadAds) announce();
  }
  function prune(v) {
    if (!on) return v;
    try {
      if (Array.isArray(v)) {                       // /watch?pbj=1 style: [{playerResponse}, ...]
        for (const it of v) if (it && typeof it === "object" && it.playerResponse) pruneObj(it.playerResponse);
      } else if (v && typeof v === "object") {
        pruneObj(v);
        if (v.playerResponse) pruneObj(v.playerResponse);
      }
    } catch (e) {}
    return v;
  }

  // 1. XHR / inline JSON
  try {
    const rawParse = JSON.parse;
    JSON.parse = function parse() { return prune(rawParse.apply(this, arguments)); };
  } catch (e) {}

  // 2. fetch("/youtubei/v1/player").then(r => r.json())
  try {
    const rawJson = Response.prototype.json;
    Response.prototype.json = function json() { return rawJson.apply(this, arguments).then(prune); };
  } catch (e) {}

  // 3. the player response embedded in the first page load
  try {
    let initial;
    Object.defineProperty(window, "ytInitialPlayerResponse", {
      configurable: true, enumerable: true,
      get() { return initial; },
      set(v) { initial = prune(v); },
    });
  } catch (e) {}

  // 4. Stall recovery (page world, because only here can we call the player's own methods).
  // Black screen = an ad is "showing" but its stream never becomes playable. If that lasts
  // 1 s, reload the real video at the same position; at most 2 tries per video.
  if (window === window.top) {
    let adSince = 0, tries = 0, lastId = "";
    setInterval(() => {
      try {
        if (!on) return;
        const p = document.getElementById("movie_player");
        if (!p) return;
        const inAd = p.classList.contains("ad-showing") || p.classList.contains("ad-interrupting");
        if (!inAd) { adSince = 0; return; }
        if (!adSince) adSince = Date.now();
        const id = new URLSearchParams(location.search).get("v") || "";
        if (id !== lastId) { lastId = id; tries = 0; }
        const vid = p.querySelector("video");
        const stuck = !vid || !isFinite(vid.duration) || vid.readyState < 2;
        if (stuck && id && tries < 2 && Date.now() - adSince > 1000 && typeof p.loadVideoById === "function") {
          tries++; adSince = Date.now();
          let t = 0; try { t = Math.floor(p.getCurrentTime() || 0); } catch (e) {}
          p.loadVideoById(id, t);
        }
      } catch (e) {}
    }, 250);
  }

  document.addEventListener("__ic_cfg", (e) => {
    try { const c = JSON.parse(e.detail); if (typeof c.yt === "boolean") on = c.yt; } catch (err) {}
  });
  try { document.dispatchEvent(new CustomEvent("__ic_ready")); } catch (e) {}
})();
