// Cosmetic filtering + your saved Zapper rules + YouTube ad skipping + the "blocked - continue?" window for popups/redirects.
// Also tells the background worker what was hidden / stopped on this page, for the live badge counter.
// The popup/redirect hooks themselves are in inject.js (page world).
(() => {
  const host = location.hostname.toLowerCase();

  // ---------------------------------------------------------------------------
  // 1. Cosmetic ad hiding + YouTube skipper
  // ---------------------------------------------------------------------------
  const COSMETIC_SEL = `
    ins.adsbygoogle, .adsbygoogle, [id^="google_ads_iframe"], [id^="google_ads_frame"],
    [id^="div-gpt-ad"], iframe[src*="doubleclick.net"], iframe[src*="googlesyndication.com"],
    iframe[src*="adservice.google"], [id^="taboola-"], .trc_rbox_container,
    .OUTBRAIN, [data-widget-id^="AR_"], #ad-container, .ad-container, .ad-banner,
    .advert, .advertisement, .adsbox, .sponsored-ad, [aria-label="advertisement" i]`;
  const COSMETIC_CSS = COSMETIC_SEL + " { display: none !important; }";

  const YT_CSS = `
    .video-ads, .ytp-ad-module, .ytp-ad-overlay-container, .ytp-ad-progress-list,
    .ytp-ad-text, .ytp-ad-image-overlay, ytd-promoted-sparkles-web-renderer,
    ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, #player-ads, #masthead-ad,
    .ytp-ad-player-overlay, .ytp-ad-player-overlay-layout {
      display: none !important; visibility: hidden !important;
      opacity: 0 !important; pointer-events: none !important;
    }`;

  function addStyle(css) {
    try {
      const el = document.createElement("style");
      el.textContent = css;
      (document.head || document.documentElement).appendChild(el);
    } catch (e) {}
  }

  // ---------------------------------------------------------------------------
  // "Ad blocked by IronClad" black screen. Covers the YouTube player for a moment so you can SEE that an ad was
  // blocked. Two triggers: yt.js reports that it removed the ad schedule from a video, or the player flips
  // into ad mode (the fallback skipper below then fast-forwards the ad). The video keeps playing underneath.
  // ---------------------------------------------------------------------------
  const FLASH_MS = 2000;               // how long the black screen stays
  const FLASH_COLOR = "#0fb8a4";       // the IronClad logo's blue-green (message and timer bar)
  const isYouTube = host === "youtube.com" || host.endsWith(".youtube.com");
  let flashOn = true;                  // the "ytFlash" setting (the app's policy while paired)
  let flashEl = null, flashStart = 0, flashPending = 0, wasAd = false;
  // ytOn / guardOn are declared further down; they are only read when an event or tick fires
  const flashAllowed = () => flashOn && ytOn && guardOn;

  let lastYtCount = 0;
  function countYt() {                 // one YouTube ad per video for the badge, however many signals fire
    const now = Date.now();
    if (!ytOn || !guardOn || now - lastYtCount < 8000) return;
    lastYtCount = now; send({ type: "ic-stat", kind: "yt" });
  }
  function askFlash() {
    countYt();
    const now = Date.now();
    // one screen per video, not one per JSON parse
    if (!flashAllowed() || flashEl || now - flashStart < 15000) return;
    flashPending = now + 8000;         // the player may not exist yet while the page is still loading
  }
  function hideFlash() {
    if (flashEl) { try { flashEl.remove(); } catch (e) {} flashEl = null; }
  }
  function showFlash(player) {
    hideFlash();
    try {
      const el = document.createElement("div");
      el.setAttribute("data-ironclad", "ad-blocked");
      // z-index 58: above the video, below YouTube's control bar (59) so the controls stay usable
      el.style.cssText = "position:absolute;inset:0;z-index:58;background:#000;display:flex;align-items:center;" +
        "justify-content:center;text-align:center;pointer-events:none;color:" + FLASH_COLOR + ";" +
        "font:700 24px/1.3 'Segoe UI',system-ui,sans-serif;letter-spacing:.2px;";
      const msg = document.createElement("div");
      msg.textContent = "Ad blocked by IronClad";
      const bar = document.createElement("div");   // shows how long the screen stays
      bar.style.cssText = "position:absolute;left:0;bottom:0;height:3px;width:100%;background:" + FLASH_COLOR + ";" +
        `transition:width ${FLASH_MS}ms linear;`;
      el.append(msg, bar);
      player.appendChild(el);
      requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = "0"; }));
      flashEl = el; flashStart = Date.now();
    } catch (e) { flashEl = null; }
  }
  function flashTick(player, ad) {
    const now = Date.now();
    if (flashEl && !flashEl.isConnected) flashEl = null;       // YouTube re-rendered the player
    if (flashEl) {
      // stays up for FLASH_MS, and longer if an ad is somehow still showing
      if (!flashAllowed() || (!ad && now - flashStart >= FLASH_MS)) hideFlash();
      return;
    }
    if (flashPending && player) {
      const go = now < flashPending && flashAllowed();
      flashPending = 0;
      if (go) showFlash(player);
    }
  }
  if (isYouTube && window === window.top) document.addEventListener("__ic_ad_blocked", askFlash);

  function youtubeSkipper() {
    if (window !== window.top) return;
    addStyle(YT_CSS);
    const SKIP_SELECTORS = [
      ".ytp-skip-ad-button", ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-container button", ".ytp-ad-skip-button-slot button",
      ".ytp-ad-overlay-close-button", ".ytp-ad-survey-answer-option",
    ];
    let saved = null;       // what we changed on the video during an ad, put back afterwards
    let watched = null;
    const inAd = (p) => !!p && (p.classList.contains("ad-showing") || p.classList.contains("ad-interrupting"));

    function tick() {
      const p = document.querySelector("#movie_player");
      if (p && p !== watched) {                    // react the instant the player flips into ad mode
        watched = p;
        try { new MutationObserver(tick).observe(p, { attributes: true, attributeFilter: ["class"] }); } catch (e) {}
      }
      const vid = p && (p.querySelector("video.html5-main-video") || p.querySelector("video"));
      const ad = inAd(p);
      if (ad && !wasAd) askFlash();                // an ad just started: it is about to be skipped
      wasAd = ad;
      flashTick(p, ad);
      if (ad) {
        if (vid) {
          try {
            if (!saved) saved = { muted: vid.muted, rate: vid.playbackRate };
            vid.muted = true;
            if (vid.paused) { const pr = vid.play(); if (pr && pr.catch) pr.catch(() => {}); }
            vid.playbackRate = 16;
            const d = vid.duration;
            if (isFinite(d) && d > 0 && vid.currentTime < d - 0.05) vid.currentTime = d;
          } catch (e) {}
        }
        for (const sel of SKIP_SELECTORS) {
          const el = document.querySelector(sel);
          if (el) { try { el.click(); } catch (e) {} }
        }
      } else if (saved) {                     // ad over: give the real video its sound and speed back
        if (vid) { try { vid.muted = saved.muted; vid.playbackRate = saved.rate || 1; } catch (e) {} }
        saved = null;
      }
    }
    setInterval(tick, 100);
    // the ad stream only becomes seekable once these fire, so check on each of them too
    for (const ev of ["durationchange", "loadedmetadata", "loadeddata", "canplay", "playing", "play", "timeupdate"]) {
      document.addEventListener(ev, tick, true);
    }
  }

  // ---------------------------------------------------------------------------
  // 2. Anti-popup / anti-redirect
  //    The page-side hooks (window.open, scripted navigation) live in inject.js, which runs in
  //    the page's own JS world. This script (isolated world) receives its reports, tells the
  //    background worker, and shows the "blocked - continue?" window in the top frame.
  // ---------------------------------------------------------------------------
  const send = (msg) => { try { return chrome.runtime.sendMessage(msg); } catch (e) { return undefined; } };
  let guardOn = true;

  // A new top-level page: the toolbar counter starts again from zero.
  if (window === window.top) send({ type: "ic-page", t: Math.floor(performance.timeOrigin) });
  // Remember what was right-clicked so the "Zap this element" menu item knows (zapper.js reads this).
  document.addEventListener("contextmenu", (e) => { window.__icLastCtx = e.target; }, true);

  let ytOn = true;
  function setGuard(on, yt) {
    guardOn = on;
    if (typeof yt === "boolean") ytOn = yt;
    try { document.dispatchEvent(new CustomEvent("__ic_cfg", { detail: JSON.stringify({ on, yt: ytOn }) })); } catch (e) {}
  }
  document.addEventListener("__ic_ready", () => setGuard(guardOn));

  function report(kind, url) {
    if (!guardOn) return;
    send({ type: "ic-blocked", kind, url: String(url || "").slice(0, 2048) });
  }
  document.addEventListener("__ic_report", (e) => {
    let d;
    try { d = JSON.parse(e.detail); } catch (err) { return; }
    if (d && (d.kind === "open" || d.kind === "redirect")) report(d.kind, d.url);
  });

  // meta-refresh redirects to another site (DOM-level, works from the isolated world)
  const BLOCKED_PROTOCOLS = /^(javascript|data|vbscript):/i;
  function isExternal(url) {
    try {
      const u = new URL(url, location.href);
      if (BLOCKED_PROTOCOLS.test(u.protocol)) return true;
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      const h = u.hostname.toLowerCase();
      return h !== host && !h.endsWith("." + host) && !host.endsWith("." + h);
    } catch (e) { return false; }
  }
  function killMetaRefresh() {
    try {
      for (const m of document.querySelectorAll('meta[http-equiv="refresh" i]')) {
        const mUrl = (m.getAttribute("content") || "").match(/url\s*=\s*['"]?([^'"\s>]+)/i);
        if (mUrl && isExternal(mUrl[1]) && guardOn) {
          m.remove();
          report("redirect", new URL(mUrl[1], location.href).href);
        }
      }
    } catch (e) {}
  }
  function installMutationGuard() {
    try {
      new MutationObserver((mutations) => {
        for (const mu of mutations) for (const n of mu.addedNodes) {
          if (n.nodeType === 1 && n.tagName === "META") killMetaRefresh();
        }
      }).observe(document.documentElement || document, { childList: true, subtree: true });
    } catch (e) {}
  }
  killMetaRefresh();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { killMetaRefresh(); installMutationGuard(); });
  } else {
    installMutationGuard();
  }

  // ---- the "blocked - continue?" window (top frame only; frames report through the background) ----
  let promptEl = null, promptTimer = null;
  function closePrompt() {
    clearTimeout(promptTimer);
    if (promptEl) { try { promptEl.remove(); } catch (e) {} promptEl = null; }
  }
  function showPrompt(msg) {
    closePrompt();
    let target = "";
    try { target = msg.url ? new URL(msg.url).hostname : ""; } catch (e) {}
    const el = document.createElement("div");
    el.setAttribute("style", "all:initial;position:fixed;top:16px;right:16px;z-index:2147483647;");
    const root = el.attachShadow({ mode: "closed" });
    const css = document.createElement("style");
    css.textContent = `
      .card{position:relative;isolation:isolate;box-sizing:border-box;width:340px;max-width:calc(100vw - 32px);color:#f5f9fc;
        background:linear-gradient(150deg,rgba(255,255,255,.20),rgba(255,255,255,.07)),rgba(14,22,38,.50);
        -webkit-backdrop-filter:blur(26px) saturate(185%);backdrop-filter:blur(26px) saturate(185%);
        border:1px solid rgba(255,255,255,.18);border-radius:22px;padding:16px 18px;
        font:14px/1.45 -apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;
        box-shadow:inset 0 1px 0 rgba(255,255,255,.42),0 16px 40px rgba(2,6,18,.5)}
      .card:before{content:"";position:absolute;inset:0;border-radius:inherit;z-index:-1;pointer-events:none;
        background:linear-gradient(180deg,rgba(255,255,255,.22),rgba(255,255,255,0) 42%)}
      h1{margin:0 0 6px;font-size:16px;font-weight:650}
      p{margin:0 0 6px;opacity:.82}
      .host{font-weight:600;word-break:break-all}
      .url{color:rgba(236,246,251,.55);font-size:12px;word-break:break-all;max-height:3.2em;overflow:hidden;margin-bottom:12px}
      .row{display:flex;gap:8px;flex-wrap:wrap}
      button{border:0;border-radius:999px;padding:9px 16px;font:600 13px -apple-system,"SF Pro Text","Segoe UI",system-ui,sans-serif;cursor:pointer}
      .keep{background:linear-gradient(180deg,#4ff0dc,#0fb8a4);color:#03221e;box-shadow:inset 0 1px 0 rgba(255,255,255,.55),0 4px 14px rgba(15,184,164,.35)}
      .go{background:rgba(255,255,255,.14);color:#f5f9fc;box-shadow:inset 0 1px 0 rgba(255,255,255,.28),inset 0 0 0 1px rgba(255,255,255,.10)}`;
    const card = document.createElement("div");
    card.className = "card";
    const h1 = document.createElement("h1");
    h1.textContent = msg.kind === "redirect" ? "Redirect blocked" : "Popup blocked";
    const p = document.createElement("p");
    p.textContent = msg.kind === "redirect"
      ? "This page tried to send you to another site. IronClad stopped it."
      : "This page tried to open a new window that looks like an ad. IronClad stopped it.";
    const hostLine = document.createElement("div");
    hostLine.className = "host";
    hostLine.textContent = target || "Blank / unknown address";
    const urlLine = document.createElement("div");
    urlLine.className = "url";
    urlLine.textContent = msg.url || "";
    const row = document.createElement("div");
    row.className = "row";
    const keep = document.createElement("button");
    keep.className = "keep"; keep.textContent = "Keep blocked";
    keep.onclick = closePrompt;
    row.append(keep);
    if (msg.canContinue && msg.url) {
      const go = document.createElement("button");
      go.className = "go"; go.textContent = "Continue anyway";
      go.onclick = async () => {
        closePrompt();
        await send({ type: "bypass", url: msg.url });       // so the network rules let this domain through for 30 min
        if (msg.kind === "redirect") {
          document.dispatchEvent(new CustomEvent("__ic_allow", { detail: msg.url }));
        } else {
          send({ type: "ic-open", url: msg.url });
        }
      };
      row.append(go);
    }
    card.append(h1, p, hostLine, urlLine, row);
    root.append(css, card);
    (document.documentElement || document).appendChild(el);
    promptEl = el;
    promptTimer = setTimeout(closePrompt, 45000);
  }
  if (window === window.top) {
    try {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && msg.type === "ic-prompt") showPrompt(msg);
      });
    } catch (e) {}
  }

  // ---------------------------------------------------------------------------
  // 2b. Your saved Zapper rules for this site + the counters the popup / badge show
  //     (rules are made by zapper.js and stored by background.js under "zap:<host>")
  // ---------------------------------------------------------------------------
  const UNLOCK_CSS = "html,body{overflow:auto!important}";
  let zapRules = [], zapStyle = null, zapOn = true, lastCos = -1, lastZap = -1, countTimer = 0, countUntil = 0;
  const hostKeys = () => {
    const l = host.replace(/^www\./, "").split("."), out = [];
    for (let i = 0; i < Math.max(1, l.length - 1); i++) out.push("zap:" + l.slice(i).join("."));
    return out;
  };
  function applyZap() {
    const rules = zapOn ? zapRules : [];
    if (!rules.length) { if (zapStyle) { try { zapStyle.remove(); } catch (e) {} zapStyle = null; } return; }
    if (!zapStyle || !zapStyle.isConnected) {
      zapStyle = document.createElement("style");
      zapStyle.setAttribute("data-ironclad", "zap-rules");
      (document.head || document.documentElement).appendChild(zapStyle);
    }
    // one rule per selector: a selector the browser rejects must not take the others down with it
    zapStyle.textContent = rules.map((r) => r.sel + "{display:none!important}").join("\n") +
      (rules.some((r) => r.unlock) ? "\n" + UNLOCK_CSS : "");
    countSoon();
  }
  function loadZap() {
    try {
      const keys = hostKeys();
      chrome.storage.local.get(keys, (got) => {
        zapRules = [];
        for (const k of keys) for (const r of (got && got[k] && got[k].rules) || []) if (r && typeof r.sel === "string") zapRules.push(r);
        applyZap();
      });
    } catch (e) {}
  }

  // How many ad slots / zapped elements this page actually has (reported once they change, a few times at most).
  function countNow() {
    countTimer = 0;
    try {
      const cos = cosmeticDone ? document.querySelectorAll(COSMETIC_SEL).length : 0;
      if (cos !== lastCos && cos > 0) { lastCos = cos; send({ type: "ic-stat", kind: "cos", n: cos }); }
      let zap = 0;
      if (zapOn) for (const r of zapRules) { try { zap += document.querySelectorAll(r.sel).length; } catch (e) {} }
      if (zap !== lastZap && zap > 0) { lastZap = zap; send({ type: "ic-stat", kind: "zap", n: zap }); }
    } catch (e) {}
  }
  function countSoon() {
    if (countTimer || Date.now() > countUntil) return;
    countTimer = setTimeout(countNow, 700);
  }
  function startCounting() {
    countUntil = Date.now() + 45000;            // pages keep adding ad slots for a while; stop watching after 45 s
    countSoon();
    try {
      const mo = new MutationObserver(countSoon);
      mo.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => mo.disconnect(), 45000);
    } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", startCounting); else startCounting();
  loadZap();

  // ---------------------------------------------------------------------------
  // 3. Apply settings (cosmetic hiding, YouTube skipper, popup guard on/off)
  // ---------------------------------------------------------------------------
  let cosmeticDone = false;
  function applySettings(settings) {
    flashOn = !settings || settings.ytFlash !== false;
    const allow = (settings && settings.allow) || [];
    const off = (settings && settings.enabled === false) ||
                allow.some((d) => host === d || host.endsWith("." + d));
    setGuard(!off, !off && (!settings || settings.youtube !== false));
    zapOn = !off && (!settings || settings.zapper !== false);
    applyZap();
    if (off || cosmeticDone) return;
    cosmeticDone = true;
    if (!settings || settings.cosmetic !== false) { addStyle(COSMETIC_CSS); countSoon(); }
    if ((!settings || settings.youtube !== false) &&
        (host === "youtube.com" || host.endsWith(".youtube.com"))) {
      youtubeSkipper();
    }
  }
  setGuard(true);   // on until the stored settings say otherwise
  chrome.storage.local.get("settings", ({ settings }) => applySettings(settings));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.settings) applySettings(changes.settings.newValue);
    if (Object.keys(changes).some((k) => k.startsWith("zap:"))) loadZap();      // a rule was saved / removed (any tab)
  });
})();
