importScripts("builtin.js"); // defines BUILTIN_DOMAINS (from IronCladOS AD_DOMAINS)
importScripts("link.js");    // connection to the IronCladOS desktop app
importScripts("badge.js");   // live, animated block counter on the toolbar icon

const CATALOG = [
  { id: "stevenblack", name: "StevenBlack Unified (ads + malware)", category: "ads",
    url: "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts" },
  { id: "pgl", name: "Peter Lowe's Ad Servers", category: "ads",
    url: "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext" },
  { id: "adguard", name: "AdGuard DNS Filter", category: "ads",
    url: "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt" },
  { id: "urlhaus", name: "URLhaus Malware Domains", category: "security",
    url: "https://urlhaus.abuse.ch/downloads/hostfile/" },
];

const DEFAULTS = {
  enabled: true,
  lists: { stevenblack: { enabled: true }, pgl: { enabled: true },
           adguard: { enabled: false }, urlhaus: { enabled: true } },
  allow: [],
  warn: true, // show the "blocked" window for ads / pop-ups that navigate to a listed domain
};

const DOMAIN_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}$/;
const LOCAL_NAMES = new Set(["localhost", "localhost.localdomain", "local", "broadcasthost", "0.0.0.0"]);
const CHUNK = 1000;          // domains per DNR rule (one rule can hold many domains)
const DAY = 24 * 3600 * 1000;
// Ad rules skip main_frame so you can still open a page that happens to be on a list;
// the malware/phishing rule blocks everything including top-level navigation.
const SUB_TYPES = ["sub_frame", "stylesheet", "script", "image", "font", "object",
                   "xmlhttprequest", "ping", "media", "websocket", "other"];
const ALL_TYPES = ["main_frame", ...SUB_TYPES];

let updating = false;
let lastMessage = "";

// ---- same parsing rules as parse_blocklist_ex() in the Python app ----------
// Rule options that do not narrow a rule. Anything else ($domain=, $image, ~third-party, $badfilter ...)
// means "only in some situations", so a domain-level blocker skips the rule instead of blocking the whole domain.
const BLOCK_OPTS_OK = new Set(["important", "third-party", "3p", "all"]);
const EXCEPTION_OPTS_OK = new Set(["important"]);
const optionsOk = (opts, allowed) => !opts || opts.slice(1).split(",").every((o) => allowed.has(o.trim()));

// Returns { block, allow }: domains to block, and domains from @@||domain^ exception rules.
function parseBlocklistEx(text) {
  const block = new Set(), allow = new Set();
  if (typeof text !== "string") return { block, allow };
  for (let line of text.split(/\r?\n/)) {
    line = line.trim().toLowerCase();
    if (!line || "#!".includes(line[0]) || line.startsWith("[") || /##|#@#|#\?#|#\$#|#%#/.test(line)) continue;
    line = line.split("#")[0].trim();
    const isException = line.startsWith("@@");
    if (isException) { line = line.slice(2); if (!line.startsWith("||")) continue; }
    let d = "";
    if (line.startsWith("||")) {
      const m = /^([a-z0-9.-]+)\^?(\$.*)?$/.exec(line.slice(2));
      if (!m || !optionsOk(m[2], isException ? EXCEPTION_OPTS_OK : BLOCK_OPTS_OK)) continue;
      d = m[1];
    } else if (line.startsWith("0.0.0.0") || line.startsWith("127.0.0.1")) {
      const parts = line.split(/\s+/);
      d = parts.length > 1 ? parts[1] : "";
    } else if (/\s/.test(line)) {
      continue;
    } else {
      d = line;
    }
    d = d.replace(/^\.+|\.+$/g, "");
    if (LOCAL_NAMES.has(d) || !DOMAIN_RE.test(d) || /^\d+$/.test(d.slice(d.lastIndexOf(".") + 1))) continue;
    (isException ? allow : block).add(d);
    if (block.size > 2000000) break;
  }
  return { block, allow };
}
const parseBlocklist = (text) => parseBlocklistEx(text).block;   // blocked domains only

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  const s = settings || {};
  return {
    enabled: s.enabled !== false,
    lists: { ...DEFAULTS.lists, ...(s.lists || {}) },
    allow: Array.isArray(s.allow) ? s.allow : [],
    warn: s.warn !== false,
    cosmetic: s.cosmetic !== false,      // hide ad slots        (app policy when paired)
    youtube: s.youtube !== false,        // YouTube ad skipping  (app policy when paired)
    ytFlash: s.ytFlash !== false,        // black "Ad skipped" screen (app policy when paired)
    zapper: s.zapper !== false,          // Zapper tool + your saved element rules (app policy when paired)
    zapAutoSave: s.zapAutoSave === true, // save every zapped element as a rule (your own preference)
    canContinue: s.canContinue !== false // "Continue anyway"    (app policy when paired)
  };
}
const saveSettings = (settings) => chrome.storage.local.set({ settings });

async function getMeta() {
  const { meta } = await chrome.storage.local.get("meta");
  return meta || {};
}

function normalizeHost(input) {
  let h = String(input || "").trim().toLowerCase();
  h = h.replace(/^[a-z]+:\/\//, "").split(/[\/?#:]/)[0].replace(/^www\./, "").replace(/\.$/, "");
  return DOMAIN_RE.test(h) ? h : "";
}

// Drop entries already covered by a parent domain in the same set (DNR matches subdomains).
function prune(domains) {
  const set = new Set(domains);
  const out = [];
  for (const d of set) {
    const labels = d.split(".");
    let covered = false;
    for (let i = 1; i < labels.length - 1; i++) {
      if (set.has(labels.slice(i).join("."))) { covered = true; break; }
    }
    if (!covered) out.push(d);
  }
  return out;
}

// Is d, or a parent of d, in the set? (DNR rules match subdomains, so this is "would a rule for the set cover d")
function coveredBy(set, d) {
  const l = d.split(".");
  for (let i = 0; i < l.length - 1; i++) if (set.has(l.slice(i).join("."))) return true;
  return false;
}
function suffixSet(domains) {
  const out = new Set();
  for (const d of domains) { const l = d.split("."); for (let i = 0; i < l.length - 1; i++) out.add(l.slice(i).join(".")); }
  return out;
}
// Exceptions that still matter: they sit above (or inside) a blocked domain. An exception never overrides the
// malware / phishing feeds.
function effectiveExceptions(exc, ads, sec) {
  const adSuf = suffixSet(ads), secSuf = suffixSet(sec), out = [];
  for (const e of exc) {
    if (secSuf.has(e) || coveredBy(sec, e)) continue;
    if (adSuf.has(e) || coveredBy(ads, e)) out.push(e);
  }
  return out;
}
// Pure: turns the raw sets into what gets installed. Built-ins are inserted first so they survive any trimming.
function finishSets(ads, sec, exc) {
  for (const d of sec) ads.delete(d);
  for (const d of exc) ads.delete(d);       // an exact exception just drops the domain
  return { ads: prune(ads), sec: prune(sec), exc: effectiveExceptions(exc, ads, sec) };
}

async function buildDomainSets(s) {
  const ads = new Set(BUILTIN_DOMAINS), sec = new Set(), exc = new Set();
  if (await isManaged()) {   // the app decides what is blocked; its sets already include the built-ins
    const rec = (await chrome.storage.local.get("list:app"))["list:app"];
    if (rec) {
      for (const d of rec.ads) ads.add(d);
      for (const d of rec.security) sec.add(d);
      for (const d of rec.exceptions || []) exc.add(d);
    }
  } else {
    for (const item of CATALOG) {
      if (!s.lists[item.id] || !s.lists[item.id].enabled) continue;
      const rec = (await chrome.storage.local.get(`list:${item.id}`))[`list:${item.id}`];
      if (!rec) continue;
      const security = item.category === "security";
      for (const d of rec.domains) (security ? sec : ads).add(d);
      if (!security) for (const d of rec.allow || []) exc.add(d);
    }
  }
  return finishSets(ads, sec, exc);
}

const ALLOW_IDS = [1, 2, 3, 4];
const EXC_ID_START = 10, EXC_ID_END = 49;
const SEC_ID_START = 100, SEC_ID_END = 4999;
const ADS_ID_START = 5000;
const BLOCK_ID_START = SEC_ID_START;
const URL_RE = "^(https?://.*)$";
const BYPASS_MS = 30 * 60 * 1000;

const chunks = (arr) => {
  const r = [];
  for (let i = 0; i < arr.length; i += CHUNK) r.push(arr.slice(i, i + CHUNK));
  return r;
};

function allowRules(allow, bypass) {
  // Dashboards that live on tracker-style hostnames (analytics.google.com, ads.twitter.com ...): the page itself is
  // never interrupted and the requests it makes are not blocked. Other sites' requests to these hosts still are.
  const rules = [{ id: 4, priority: 3, action: { type: "allowAllRequests" },
                   condition: { requestDomains: NAV_SAFE_HOSTS, resourceTypes: ["main_frame"] } }];
  if (allow.length) {
    // "Pause on this site": allow everything loaded by pages on these domains, and never block the domains themselves.
    rules.push({ id: 1, priority: 3, action: { type: "allowAllRequests" },
                 condition: { requestDomains: allow, resourceTypes: ["main_frame", "sub_frame"] } });
    rules.push({ id: 2, priority: 3, action: { type: "allow" },
                 condition: { requestDomains: allow, resourceTypes: ALL_TYPES } });
  }
  if (bypass.length) {
    // "Continue anyway": temporary, expires after BYPASS_MS.
    rules.push({ id: 3, priority: 3, action: { type: "allow" },
                 condition: { requestDomains: bypass, resourceTypes: ALL_TYPES } });
  }
  return rules;
}

// Top-level navigations to a listed domain are redirected to our "blocked" window,
// with the original URL carried in the fragment.
function interstitial(reason) {
  return { type: "redirect",
           redirect: { regexSubstitution: `chrome-extension://${chrome.runtime.id}/blocked.html?r=${reason}#\\1` } };
}

function rulesFor(s, adsArr, secArr, bypass, excArr = []) {
  const rules = allowRules(s.allow, bypass);
  let id = EXC_ID_START;
  for (const c of chunks(excArr)) {            // list exceptions beat the block rules (priority 3)
    if (id > EXC_ID_END) break;
    rules.push({ id: id++, priority: 3, action: { type: "allow" },
                 condition: { requestDomains: c, resourceTypes: ALL_TYPES } });
  }
  id = SEC_ID_START;
  for (const c of chunks(secArr)) {
    if (id + 1 > SEC_ID_END) break;
    rules.push({ id: id++, priority: 2, action: { type: "block" },
                 condition: { requestDomains: c, resourceTypes: SUB_TYPES } });
    rules.push({ id: id++, priority: 2, action: interstitial("security"),
                 condition: { requestDomains: c, regexFilter: URL_RE, resourceTypes: ["main_frame"] } });
  }
  id = ADS_ID_START;
  for (const c of chunks(adsArr)) {
    rules.push({ id: id++, priority: 1, action: { type: "block" },
                 condition: { requestDomains: c, resourceTypes: SUB_TYPES } });
    if (s.warn) {
      rules.push({ id: id++, priority: 1, action: interstitial("ads"),
                   condition: { requestDomains: c, regexFilter: URL_RE, resourceTypes: ["main_frame"] } });
    }
  }
  return rules;
}

// Install the rules. Normally one atomic call. If Chrome rejects it, find out WHICH domains it rejects and
// install everything else (the old code threw away half of the list and said so only in a hidden panel).
const REJECT_BUDGET = 4000;                      // calls to Chrome we are willing to spend finding bad entries
async function installRules(removeRuleIds, rules) {
  const dnr = chrome.declarativeNetRequest;
  const msg = (e) => String((e && e.message) || e);
  try {
    await dnr.updateDynamicRules({ removeRuleIds, addRules: rules });
    return { dropped: 0, sample: "", error: "" };
  } catch (firstError) {
    const ctx = { dropped: new Set(), sample: "", error: "", calls: 0, used: new Set(rules.map((r) => r.id)),
                  nextId: { exc: EXC_ID_START, sec: SEC_ID_START, ads: ADS_ID_START } };
    try { await dnr.updateDynamicRules({ removeRuleIds, addRules: [] }); }
    catch (e) { return { dropped: 0, sample: "", error: msg(e) }; }
    const kindOf = (r) => r.id >= ADS_ID_START ? "ads" : r.id >= SEC_ID_START ? "sec" : r.id >= EXC_ID_START ? "exc" : "";
    const alloc = (kind) => { while (ctx.used.has(ctx.nextId[kind])) ctx.nextId[kind]++; ctx.used.add(ctx.nextId[kind]); return ctx.nextId[kind]; };
    const giveUp = (rule, e) => {
      const doms = rule.condition.requestDomains;
      if (Array.isArray(doms) && kindOf(rule)) { for (const d of doms) ctx.dropped.add(d); if (!ctx.sample) ctx.sample = doms[0]; }
      if (!ctx.error) ctx.error = msg(e);
    };
    const add = async (rule) => {
      if (ctx.calls++ >= REJECT_BUDGET) return giveUp(rule, "too many rejected entries");
      try { await dnr.updateDynamicRules({ addRules: [rule] }); }
      catch (e) {
        const doms = rule.condition.requestDomains, kind = kindOf(rule);
        if (!kind || !Array.isArray(doms) || doms.length <= 1) return giveUp(rule, e);
        const mid = doms.length >> 1;           // split and retry: the culprit ends up alone in a tiny rule
        await add({ ...rule, condition: { ...rule.condition, requestDomains: doms.slice(0, mid) } });
        await add({ ...rule, id: alloc(kind), condition: { ...rule.condition, requestDomains: doms.slice(mid) } });
      }
    };
    for (const r of rules) await add(r);
    return { dropped: ctx.dropped.size, sample: ctx.sample, error: ctx.dropped.size ? "" : (ctx.error || msg(firstError)) };
  }
}

async function getBypass() {
  const { bypass } = await chrome.storage.local.get("bypass");
  const stored = bypass || {};
  const now = Date.now(), live = {};
  for (const [h, exp] of Object.entries(stored)) if (exp > now) live[h] = exp;
  if (Object.keys(live).length !== Object.keys(stored).length) await chrome.storage.local.set({ bypass: live });
  return live;
}

// Cheap update: only the allowlist / bypass rules (used when you pause a site or click "Continue anyway").
async function applyAllowRules() {
  const s = await getSettings();
  const bypass = Object.keys(await getBypass());
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: ALLOW_IDS, addRules: s.enabled ? allowRules(s.allow, bypass) : [] });
}

async function applyRules() {
  const s = await getSettings();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((r) => r.id);
  linkSecMaxId = SEC_ID_END;
  if (!s.enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] });
    await chrome.storage.local.set({ applied: { total: 0, error: "", truncated: false, dropped: 0, sample: "", secMaxId: SEC_ID_END } });
    return;
  }
  const bypass = Object.keys(await getBypass());
  const { ads, sec, exc } = await buildDomainSets(s);
  const r = await installRules(removeRuleIds, rulesFor(s, ads, sec, bypass, exc));
  await chrome.storage.local.set({ applied: {
    total: Math.max(0, ads.length + sec.length - r.dropped), error: r.error, truncated: r.dropped > 0,
    dropped: r.dropped, sample: r.sample, secMaxId: SEC_ID_END } });
}

async function fetchList(item) {
  const res = await fetch(item.url, { cache: "no-store", signal: AbortSignal.timeout(60000) });
  if (!res.ok) throw new Error(`${item.name}: HTTP ${res.status}`);
  const { block, allow } = parseBlocklistEx(await res.text());
  const domains = [...block];
  if (!domains.length) throw new Error(`${item.name}: no domains found`);   // keeps the previous copy
  const meta = await getMeta();
  meta[item.id] = { count: domains.length, updated: Date.now() };
  await chrome.storage.local.set({ [`list:${item.id}`]: { domains, allow: [...allow] }, meta });
}

async function updateLists(ids) {
  if (updating || await isManaged()) return;
  updating = true;
  lastMessage = "Updating lists…";
  try {
    const s = await getSettings();
    const items = CATALOG.filter((i) => (ids ? ids.includes(i.id) : s.lists[i.id].enabled));
    const errors = [];
    await Promise.all(items.map((i) => fetchList(i).catch((e) => errors.push(String((e && e.message) || e)))));
    await applyRules();
    lastMessage = errors.length ? "Some lists failed: " + errors.join("; ") : "Lists updated.";
  } finally {
    updating = false;
  }
}

async function updateStale() {
  if (await isManaged()) return;
  const [s, meta] = await Promise.all([getSettings(), getMeta()]);
  const stale = CATALOG.filter((i) => s.lists[i.id].enabled &&
    (!meta[i.id] || Date.now() - meta[i.id].updated > DAY)).map((i) => i.id);
  if (stale.length) await updateLists(stale);
}

async function getState() {
  const [s, meta, { applied }, link] = await Promise.all([
    getSettings(), getMeta(), chrome.storage.local.get("applied"), getLink()]);
  return {
    managed: !!link.token,
    link: publicLink(link, meta.app ? meta.app.count : 0),
    canContinue: s.canContinue,
    enabled: s.enabled,
    allow: s.allow,
    warn: s.warn,
    ytFlash: s.ytFlash,
    zapper: s.zapper,
    zapAutoSave: s.zapAutoSave,
    badgeLive: IcBadge.own,
    builtin: BUILTIN_DOMAINS.length,
    lists: CATALOG.map((i) => ({ id: i.id, name: i.name, category: i.category,
      enabled: !!s.lists[i.id].enabled, count: meta[i.id] ? meta[i.id].count : null,
      updated: meta[i.id] ? meta[i.id].updated : null })),
    applied: applied || { total: 0, error: "", truncated: false, dropped: 0, sample: "" },
    updating, message: lastMessage,
  };
}

const LOCKED_WHEN_MANAGED = new Set(["enable", "toggleList", "allow", "unallow", "setWarn", "setYtFlash", "setZapper", "update"]);

async function handle(msg) {
  const s = await getSettings();
  const link = await getLink();
  const managed = !!link.token;
  if (managed && (LOCKED_WHEN_MANAGED.has(msg.type) ||
      (msg.type === "bypass" && !s.canContinue) ||
      // only the app may disconnect us; if it's gone we allow a local disconnect so you're never stuck
      ((msg.type === "linkUnpair" || msg.type === "linkPort") && link.status === "connected"))) {
    const st = await getState();
    st.notice = "Managed by IronCladOS - change this in the app.";
    return st;
  }
  switch (msg.type) {
    case "linkPair": {
      const p = linkPair();
      await Promise.race([p, new Promise((r) => setTimeout(r, 400))]);
      break;
    }
    case "linkSync": await linkSync(true); break;
    case "linkUnpair": await linkUnpair(); break;
    case "linkPort": {
      const n = parseInt(msg.value, 10);
      if (n >= 1024 && n <= 65535) { const l = await getLink(); l.port = n; await saveLink(l); }
      break;
    }
    case "scan": return linkScan(String(msg.url || ""));
    case "enable":
      s.enabled = !!msg.value; await saveSettings(s); await applyRules(); break;
    case "toggleList": {
      if (!s.lists[msg.id]) break;
      s.lists[msg.id] = { enabled: !s.lists[msg.id].enabled };
      await saveSettings(s);
      const meta = await getMeta();
      if (s.lists[msg.id].enabled && !meta[msg.id]) await updateLists([msg.id]); else await applyRules();
      break;
    }
    case "allow": {
      const h = normalizeHost(msg.host);
      if (h && !s.allow.includes(h)) { s.allow.push(h); await saveSettings(s); await applyAllowRules(); }
      break;
    }
    case "unallow":
      s.allow = s.allow.filter((d) => d !== msg.host); await saveSettings(s); await applyAllowRules(); break;
    case "setWarn":
      s.warn = !!msg.value; await saveSettings(s); await applyRules(); break;
    case "setYtFlash":
      s.ytFlash = !!msg.value; await saveSettings(s); break;
    case "setZapper":
      s.zapper = !!msg.value; await saveSettings(s); break;
    case "setZapSave":                  // your own preference, allowed while managed
      s.zapAutoSave = !!msg.value; await saveSettings(s); break;
    case "bypass": {            // "Continue anyway" from the blocked window
      let u;
      try { u = new URL(msg.url); } catch (e) { break; }
      const host = u.hostname.toLowerCase().replace(/\.$/, "");
      if ((u.protocol !== "http:" && u.protocol !== "https:") || !DOMAIN_RE.test(host)) break;
      const live = await getBypass();
      live[host] = Date.now() + BYPASS_MS;
      await chrome.storage.local.set({ bypass: live });
      await applyAllowRules();
      chrome.alarms.create("bypass-expire", { delayInMinutes: BYPASS_MS / 60000 + 1 });
      break;
    }
    case "update":
      await updateLists(); break;
  }
  return getState();
}

// ---- popup / redirect guard (reports come from content.js, which gets them from inject.js) ----
const promptSeen = new Map();   // tabId -> { t, url }  (stops a page from flooding the user with prompts)

async function onIcBlocked(msg, sender) {
  const tabId = sender && sender.tab ? sender.tab.id : undefined;
  if (tabId === undefined) return;
  const s = await getSettings();
  if (!s.enabled) return;
  let host = "";
  try { host = new URL(msg.url).hostname; } catch (e) {}
  noteEvent(host, "popup");
  IcBadge.add(tabId, "popup");                             // the badge pulses for stopped pop-ups too
  if (!s.warn) return;                                     // "show the blocked window" is off: block silently
  const now = Date.now(), prev = promptSeen.get(tabId);
  if (prev && prev.url === msg.url && now - prev.t < 4000) return;
  promptSeen.set(tabId, { t: now, url: msg.url });
  if (promptSeen.size > 200) promptSeen.delete(promptSeen.keys().next().value);
  chrome.tabs.sendMessage(tabId, {
    type: "ic-prompt", kind: msg.kind === "redirect" ? "redirect" : "open", url: msg.url,
    canContinue: s.canContinue && !!msg.url,
  }, { frameId: 0 }).catch(() => {});
}

async function onIcOpen(msg, sender) {                     // "Continue anyway" on a blocked popup
  const s = await getSettings();
  if (!s.canContinue) return;
  let u;
  try { u = new URL(msg.url); } catch (e) { return; }
  if (u.protocol !== "http:" && u.protocol !== "https:") return;
  const opts = { url: u.href, active: true };
  if (sender && sender.tab) opts.openerTabId = sender.tab.id;
  await chrome.tabs.create(opts);
}

// ---- Zapper: your own "hide this element" rules (stored locally, per site) -------------------------------------
// storage:  "zap:<host>" -> { rules: [{ id, sel, unlock, t }] }      "zapIdx" -> { host: ruleCount }
const ZAP_MAX_RULES = 200, ZAP_MAX_HOSTS = 500;
const zapHostOf = (url) => {
  try { return new URL(url).hostname.toLowerCase().replace(/^www\./, "").replace(/\.$/, ""); } catch (e) { return ""; }
};
const zapHostOk = (h) => !!h && h.length <= 253 && /^[a-z0-9.-]+$/.test(h);
function zapSuffixes(h) {                    // a.b.example.com -> a.b.example.com, b.example.com, example.com
  const l = h.split("."), out = [];
  for (let i = 0; i < Math.max(1, l.length - 1); i++) out.push(l.slice(i).join("."));
  return out;
}
// A selector ends up inside a CSS rule, so refuse anything that could close or open one ( { } ; ) or start a comment.
// (">" is fine: it is the child combinator.)
const zapSelOk = (sel) => typeof sel === "string" && sel.length > 0 && sel.length <= 400 &&
  !/[{};<]/.test(sel) && !sel.includes("/*") && !sel.trim().startsWith("@");

async function zapRulesFor(host) {
  const keys = zapSuffixes(host).map((h) => "zap:" + h);
  const got = await chrome.storage.local.get(keys);
  const out = [];
  for (const k of keys) for (const r of (got[k] && got[k].rules) || []) out.push({ ...r, host: k.slice(4) });
  return out;
}
async function zapSave(host, sel, unlock) {
  if (!zapHostOk(host) || !zapSelOk(sel)) return { ok: false, error: "That element can't be saved as a rule." };
  const key = "zap:" + host;
  const [{ [key]: rec }, { zapIdx }] = await Promise.all([chrome.storage.local.get(key), chrome.storage.local.get("zapIdx")]);
  const rules = (rec && rec.rules) || [], idx = zapIdx || {};
  const old = rules.find((r) => r.sel === sel);
  if (old) return { ok: true, id: old.id, host };
  if (rules.length >= ZAP_MAX_RULES) return { ok: false, error: `This site already has ${ZAP_MAX_RULES} saved rules.` };
  if (!idx[host] && Object.keys(idx).length >= ZAP_MAX_HOSTS) return { ok: false, error: "Too many sites have saved rules." };
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  rules.push({ id, sel, unlock: !!unlock, t: Date.now() });
  idx[host] = rules.length;
  await chrome.storage.local.set({ [key]: { rules }, zapIdx: idx });
  return { ok: true, id, host };
}
async function zapDelete(host, id) {
  if (!zapHostOk(host)) return { ok: false };
  const key = "zap:" + host;
  const [{ [key]: rec }, { zapIdx }] = await Promise.all([chrome.storage.local.get(key), chrome.storage.local.get("zapIdx")]);
  const rules = ((rec && rec.rules) || []).filter((r) => r.id !== id), idx = zapIdx || {};
  if (rules.length) { idx[host] = rules.length; await chrome.storage.local.set({ [key]: { rules }, zapIdx: idx }); }
  else { delete idx[host]; await chrome.storage.local.remove(key); await chrome.storage.local.set({ zapIdx: idx }); }
  return { ok: true };
}
async function zapClear(host) {
  if (!zapHostOk(host)) return { ok: false };
  const { zapIdx } = await chrome.storage.local.get("zapIdx");
  const idx = zapIdx || {};
  delete idx[host];
  await chrome.storage.local.remove("zap:" + host);
  await chrome.storage.local.set({ zapIdx: idx });
  return { ok: true };
}

// Start the picker (or zap the element you right-clicked) in a tab. zapper.js is injected on demand.
async function zapInject(tabId, frameId, mode) {
  const s = await getSettings();
  if (!s.zapper) return { ok: false, error: "The Zapper is turned off in IronCladOS." };
  try {
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId || 0] }, files: ["zapper.js"] });
    await chrome.tabs.sendMessage(tabId, { type: "zap", mode }, { frameId: frameId || 0 });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: "The Zapper can't run on this page (Chrome doesn't let extensions change it)." };
  }
}

function setupMenus() {
  chrome.contextMenus.removeAll(() => {
    void chrome.runtime.lastError;
    const contexts = ["page", "frame", "selection", "link", "image", "video", "audio"];
    chrome.contextMenus.create({ id: "ic-zap-here", title: "IronClad: Zap this element", contexts });
    chrome.contextMenus.create({ id: "ic-zap-pick", title: "IronClad: Pick an element to zap…", contexts });
  });
}
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === "ic-zap-pick") zapInject(tab.id, 0, "pick");
  else if (info.menuItemId === "ic-zap-here") zapInject(tab.id, info.frameId || 0, "last");
});
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== "toggle-zapper") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id != null) zapInject(tab.id, 0, "toggle");
});

chrome.runtime.onConnect.addListener((port) => { if (port.name === "popup") IcBadge.attachPort(port); });

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const tabId = sender && sender.tab ? sender.tab.id : undefined;
  if (msg && msg.type === "state") { getState().then(send); return true; }
  if (msg && msg.type === "ic-blocked") { onIcBlocked(msg, sender).catch(() => {}); return false; }
  if (msg && msg.type === "ic-open") { onIcOpen(msg, sender).then(() => send({ ok: true }), () => send({ ok: false })); return true; }
  // numbers from content scripts -> badge / popup
  if (msg && msg.type === "ic-page") { if (sender.frameId === 0) IcBadge.pageStart(tabId, msg.t); return false; }
  if (msg && msg.type === "ic-stat") {
    if (msg.kind === "yt") IcBadge.add(tabId, "yt");
    else IcBadge.setMax(tabId, msg.kind, sender.frameId || 0, Math.max(0, msg.n | 0));
    return false;
  }
  if (msg && msg.type === "tabStats") { send(IcBadge.stats(msg.tabId)); return false; }
  // Zapper
  if (msg && msg.type === "zapStart") { zapInject(msg.tabId, 0, msg.mode || "toggle").then(send); return true; }
  if (msg && msg.type === "zapList") { zapRulesFor(zapHostOf(msg.url)).then((rules) => send({ rules })); return true; }
  if (msg && msg.type === "zapSave") { zapSave(zapHostOf(sender.url || (sender.tab && sender.tab.url)), msg.sel, msg.unlock).then(send); return true; }
  if (msg && msg.type === "zapDelete") { zapDelete(String(msg.host || ""), String(msg.id || "")).then(send); return true; }
  if (msg && msg.type === "zapClear") { zapClear(String(msg.host || "")).then(send); return true; }
  handle(msg || {}).then(send, (e) => send({ error: String((e && e.message) || e) }));
  return true;
});

function setup() {
  chrome.alarms.get("refresh", (a) => { if (!a) chrome.alarms.create("refresh", { periodInMinutes: 360 }); });
  chrome.alarms.get("link-sync", (a) => { if (!a) chrome.alarms.create("link-sync", { periodInMinutes: 0.5 }); });
}
IcBadge.init();          // every time the worker wakes: counters, badge animation, tab tracking
chrome.runtime.onInstalled.addListener(async () => {
  setup();
  setupMenus();
  await applyRules();                    // built-in list works immediately
  updateLists().catch(() => {});         // then pull the online lists
});
chrome.runtime.onStartup.addListener(() => { setup(); setupMenus(); applyAllowRules().catch(() => {}); linkSync().catch(() => {}); });
chrome.tabs.onActivated.addListener(syncSoon);
chrome.tabs.onUpdated.addListener((_id, info) => { if (info.status === "loading") syncSoon(); });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "refresh") updateStale().catch(() => {});
  if (a.name === "bypass-expire") applyAllowRules().catch(() => {});
  if (a.name === "link-sync") { linkSync().catch(() => {}); flushEvents().catch(() => {}); }
});
