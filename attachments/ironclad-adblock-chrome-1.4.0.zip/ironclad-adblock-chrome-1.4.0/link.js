// link.js - connection to the IronCladOS desktop app (local API on 127.0.0.1).
// While paired, the app is the control panel: this extension follows the app's
// blocklists, allowlist and policy, and its own switches are locked (see background.js).

const LINK_DEFAULT_PORT = 8898;
let linkBusy = false;
let linkPaired;            // cached: true / false once known
let linkSecMaxId;          // highest dynamic-rule id that belongs to the malware list
let flushTimer = null;
let lastTabSync = 0;
const eventBuf = new Map(); // "host|reason" -> {host, reason, count}
const sameJson = (a, b) => JSON.stringify(a) === JSON.stringify(b);

async function getLink() {
  const { link } = await chrome.storage.local.get("link");
  return { port: LINK_DEFAULT_PORT, token: "", rev: "", lastSeen: 0, status: "unpaired", error: "", ...(link || {}) };
}
async function saveLink(link) {
  linkPaired = !!link.token;
  await chrome.storage.local.set({ link });
}
async function isManaged() { return !!(await getLink()).token; }
function publicLink(link, domains) {
  const { token, rev, pairStarted, ...rest } = link;
  return { ...rest, paired: !!token, domains: domains || 0 };
}

async function linkFetch(link, path, opts = {}) {
  const headers = { "Content-Type": "application/json" };
  if (link.token) headers.Authorization = "Bearer " + link.token;
  const res = await fetch(`http://127.0.0.1:${link.port}${path}`, {
    method: opts.method || "GET", headers, cache: "no-store",
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    signal: AbortSignal.timeout(opts.timeout || 8000) });
  let data = null;
  try { data = await res.json(); } catch (e) {}
  return { ok: res.ok, status: res.status, data };
}

// Back to a normal standalone extension (app forgot us, or the user disconnected while the app was gone).
async function linkResetLocal(link, status, error) {
  link.token = ""; link.rev = ""; link.status = status; link.error = error;
  await chrome.storage.local.remove("list:app");
  const meta = await getMeta(); delete meta.app;
  await chrome.storage.local.set({ meta });
  const s = await getSettings();
  s.cosmetic = s.youtube = s.canContinue = s.zapper = true;
  await saveSettings(s);
  await saveLink(link);
  await applyRules();
  updateStale().catch(() => {});
}

async function linkPair() {
  let link = await getLink();
  if (link.status === "pairing" && Date.now() - (link.pairStarted || 0) < 90000) return;
  link = { ...link, token: "", status: "pairing", error: "", pairStarted: Date.now() };
  await saveLink(link);
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  try {
    const r = await linkFetch(link, "/api/pair", { method: "POST", timeout: 90000,
      body: { name: "IronClad Ad Blocker " + chrome.runtime.getManifest().version } });
    if (r.ok && r.data && r.data.token) {
      link.token = r.data.token; link.status = "connected"; link.error = ""; link.rev = "";
      await saveLink(link);
      // One-time import of any allowlist the extension already had, then the app takes over.
      const s = await getSettings();
      if (s.allow.length) await linkFetch(link, "/api/allow", { method: "POST", body: { add: s.allow } }).catch(() => {});
      await linkSync(true);
      return;
    }
    if (r.status === 403) { link.status = "denied"; link.error = "The request was declined in IronCladOS."; }
    else if (r.status === 429) { link.status = "error"; link.error = "Try again in a few seconds."; }
    else { link.status = "error"; link.error = (r.data && r.data.error) || `Unexpected response (${r.status}).`; }
  } catch (e) {
    link.status = "offline";
    link.error = "Can't reach IronCladOS. Is the app running with the Chrome link turned on?";
  } finally { clearInterval(keepAlive); }
  await saveLink(link);
}

async function linkSync(force) {
  if (linkBusy) return;
  linkBusy = true;
  let link = await getLink();
  try {
    if (!link.token) return;
    const r = await linkFetch(link, `/api/sync?rev=${encodeURIComponent(force ? "" : link.rev)}`, { timeout: 60000 });
    if (r.status === 401) {   // the app forgot this browser: control returns to the extension
      await linkResetLocal(link, "unpaired", "IronCladOS disconnected this extension. You can connect again.");
      return;
    }
    if (!r.ok || !r.data) throw new Error("bad response");
    const d = r.data, p = d.policy || {};
    link.status = "connected"; link.error = ""; link.lastSeen = Date.now();
    let rebuild = false;
    if (!d.unchanged) {
      const meta = await getMeta();
      meta.app = { count: (d.ads || []).length + (d.security || []).length, updated: Date.now() };
      await chrome.storage.local.set({ "list:app": { ads: d.ads || [], security: d.security || [], exceptions: d.exceptions || [] }, meta });
      link.rev = d.rev; rebuild = true;
    }
    // The app is the single source of truth for allowlist and policy.
    const s = await getSettings();
    const appAllow = (d.allow || []).filter((h) => DOMAIN_RE.test(h)).sort();
    const next = { ...s, allow: appAllow,
      enabled: p.enabled !== false, warn: p.warn !== false,
      cosmetic: p.cosmetic !== false, youtube: p.youtube !== false, ytFlash: p.yt_flash !== false,
      canContinue: p.can_continue !== false, zapper: p.zapper !== false };
    const allowChanged = !sameJson([...s.allow].sort(), appAllow);
    const rulesChanged = next.enabled !== s.enabled || next.warn !== s.warn;
    if (allowChanged || rulesChanged || next.cosmetic !== s.cosmetic ||
        next.youtube !== s.youtube || next.ytFlash !== s.ytFlash || next.canContinue !== s.canContinue ||
        next.zapper !== s.zapper) await saveSettings(next);
    try {
      if (rebuild || rulesChanged) await applyRules();
      else if (allowChanged) await applyAllowRules();
    } catch (e) {            // reached the app, but Chrome refused the rules: say so instead of claiming it is offline
      link.error = "Chrome could not apply the app's rules: " + String((e && e.message) || e);
    }
  } catch (e) {
    link.status = "offline"; link.error = "Can't reach IronCladOS. Is the app running?";
  } finally {
    await saveLink(link);
    linkBusy = false;
  }
}

function syncSoon() {          // called when the user switches tabs: picks up app changes quickly
  if (Date.now() - lastTabSync < 10000) return;
  lastTabSync = Date.now();
  linkSync().catch(() => {});
}

async function linkUnpair() {
  const link = await getLink();
  if (link.token) await linkFetch(link, "/api/unpair", { method: "POST", timeout: 3000, body: {} }).catch(() => {});
  await linkResetLocal(link, "unpaired", "");
}

async function linkScan(url) {
  const link = await getLink();
  if (!link.token) return { error: "Not connected to IronCladOS." };
  try {
    const r = await linkFetch(link, "/api/scan", { method: "POST", body: { url }, timeout: 15000 });
    return r.ok ? r.data : { error: (r.data && r.data.error) || `HTTP ${r.status}` };
  } catch (e) { return { error: "Can't reach IronCladOS." }; }
}

// ---- report what Chrome blocked back to the app (domain names only) -------------
function noteEvent(host, reason) {
  if (linkPaired === false || !host) return;
  const key = host + "|" + reason;
  const e = eventBuf.get(key) || { host, reason, count: 0 };
  e.count++; eventBuf.set(key, e);
  if (eventBuf.size > 1000) eventBuf.delete(eventBuf.keys().next().value);
  if (!flushTimer) flushTimer = setTimeout(flushEvents, 3000);
}

function onRuleMatched(info) {
  const id = info && info.rule && info.rule.ruleId;
  if (!(id >= BLOCK_ID_START)) return;
  let host;
  try { host = new URL(info.request.url).hostname; } catch (e) { return; }
  noteEvent(host, linkSecMaxId !== undefined && id <= linkSecMaxId ? "security" : "ads");
}

async function flushEvents() {
  flushTimer = null;
  if (!eventBuf.size) return;
  const link = await getLink();
  if (!link.token) { eventBuf.clear(); return; }
  const sent = [...eventBuf.entries()].slice(0, 300).map(([k, e]) => [k, e.host, e.reason, e.count]);
  try {
    const r = await linkFetch(link, "/api/events", { method: "POST", timeout: 5000,
      body: { events: sent.map(([, host, reason, count]) => ({ host, reason, count })) } });
    if (r.ok) for (const [k, , , n] of sent) {
      const cur = eventBuf.get(k);
      if (cur) { cur.count -= n; if (cur.count <= 0) eventBuf.delete(k); }
    }
  } catch (e) {}
  if (eventBuf.size && !flushTimer) flushTimer = setTimeout(flushEvents, 10000);
}

// onRuleMatchedDebug only exists for unpacked installs with declarativeNetRequestFeedback.
if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(onRuleMatched);
}
getLink().then((l) => { linkPaired = !!l.token; });
chrome.storage.local.get("applied").then(({ applied }) => {
  if (applied && applied.secMaxId !== undefined) linkSecMaxId = applied.secMaxId;
});
